executable="G-2"

nsteps_save="10"

n_particles="400"

Lp="2"

box_x="20"

box_y="20"

T="1"

v_trap_ini="0.0"

Nv="1"

v_per_decade="1"

k_trap="10"

k_pol="10"

R="0.125"

eps="10"

R0="1.25"

eps0="20"

dt="1e-3"

tt="200"

Lambda="0.5"

f_list=("0" "2" "4" "6" "8" "10")



make


for f_active in "${f_list[@]}"; do
	for n in {1..10}; do
  		./$executable $nsteps_save $n_particles $Lp $box_x $box_y $T $v_trap_ini $Nv $v_per_decade $k_trap $k_pol $R $eps $R0 $eps0 $Lambda $f_active $n $dt $tt
  	done
done
