#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//Defining useful costants
#define PI 3.14159265358979323846

/*
####################
PROTOTYPES
####################
*/

/* uniform
Sample a random number from a uniform distribution between 0 and 1;
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double uniform(); 

/* uniform_interval
Sample a random number from a uniform distribution between inf and sup;
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double uniform_interval(double inf, double sup);

/* power_sampler
Sample a random variable from the power law distribution p(x)=x^n with x€[inf, sup]
The distribution is normalized directly from the algorithm
The sampling is done by Inversion Method
*/
double power_sampler(double n, double inf, double sup);

/* box_muller
Sample two gaussian random variable from a normal distribution with loc=mu and sc=sigma
The sampling is done by coordinates transformation + inversion method
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double * box_muller(double mu, double sigma);



/* rejection_method_sampling
Sample from a distribution double f(double x, double *fPar) with rejection method using
double g(double x, double *gPar) as limiting function and the corresponding inverse cdf for sampling from g(x) with inversion method  double inv_F(double y, double * inv_FPar)
double c  is the costant used in the rejection method
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double rejection_method_sampling(double(*f)(double, double *), double(*g)(double, double *), double(*inv_F)(double, double*), double c, double *fPar, double *gPar, double *inv_FPar);


/*crude_monte_carlo
Crude monte carlo method to compute the integral of a function f.
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double crude_monte_carlo(int N, double inf, double sup, double(*f)(double, double *), double * fPar);

/*random_integer
Sample a random integer between inf and sup
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
int random_integer(int inf, int sup);

