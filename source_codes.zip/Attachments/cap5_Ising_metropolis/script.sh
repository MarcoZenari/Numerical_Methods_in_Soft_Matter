 #!/bin/bash 
 
code=ising_glauber_metropolis.c
module=nmsm.c

gcc -o2 $code $module -lm -o es.out
./es.out

rm es.out
