//main libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//hamiltonian of the system k=1, m=1
double hamiltonian(double x, double p){
	double out = 0.;
	out = 1./2. *(x*x+p*p);
	return out;
}

//shadow hamiltonian for the symplectic integrator
double shadow_hamiltonian(double dt, double x, double p){
	double out = 0.;
	out = hamiltonian(x, p)- dt*x*p/2.;
	return out;
}

//euler I order integrator
void non_symplectic_integrator(double dt, double *x, double *p, double *H, double*t){
	double p_old = *p;
	double x_old = *x;
	*p = p_old - dt*x_old;
	*x = x_old + dt*p_old; 
	*H = hamiltonian(*x, *p);
	*t = *t +dt;
}

//symplectic version
void symplectic_integrator(double dt, double *x, double *p, double *H, double*t){
	double p_old = *p;
	double x_old = *x;
	*p = p_old - dt*x_old;
	*x = x_old + dt*(*p); 
	*H = hamiltonian(*x, *p);
	*t = *t +dt;
}

int main(){

	//intial conditions
	double p0 = 0.;
	double x0 = 1.;
	
	//integration parameters
	double dt = 0.001; //time-step
	int N_timesteps = 10000; //number or time-step evolutions
	double max_time = N_timesteps*dt;
		
	//allocating memory
	double* x = (double*)malloc(sizeof(double));
	double* p =(double*)malloc(sizeof(double));
	double* t =(double*)malloc(sizeof(double));
	double* H =(double*)malloc(sizeof(double));
	
	//file to save the data
	
	//initialization
	*x = x0;
	*p = p0;
	*H = hamiltonian(*x, *p);
	*t = 0.;
	
	//file to save the data
	char filename[150];
	
	sprintf(filename, "data/harmonic_oscillator_first_ordern_symplectic_integrator_time%f_dt%f.txt", max_time, dt);
	
	//Creating file to save the data
	FILE * file = fopen(filename, "w");
	
	fprintf(file, "#time\tx\tp\tH\tsH\n");
	
	//integration
	for(int n = 0; n < N_timesteps; n++){
		fprintf(file, "%f\t%f\t%f\t%f\t%f\n", *t, *x, *p, *H, shadow_hamiltonian(dt, *x, *p));
		//non_symplectic_integrator(dt, x, p, H, t);
		symplectic_integrator(dt, x, p, H, t);
	}
	
	//freeing memory
	free(x);
	free(p);
	free(H);
	free(t);
	
	//closing the file
	fclose(file);
	

}
