//main libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//hamiltonian of the system k=1, m=1
double hamiltonian(double x, double p){
	double out = 0.;
	out = 1./2. *(x*x+p*p);
	return out;
}

//force of the harmonic oscillator
double force(double x){
	double out = -x; //k = 1
	return out;
}

//accelaration in the harmonic oscillator
double acc(double x){
	double out = -x;
	return out;
}

//velocty-verlet
void velocity_verlet(double dt, double *x, double *p, double *H, double *t){
	double force_old = force(*x);
	*x = *x + *p *dt + force_old/2.*dt*dt;  //m=1 --> v=p
	*p = *p + (force_old+force(*x))/2.*dt;  //m=1
	*H = hamiltonian(*x, *p);
	*t = *t +dt;
}

//verlet algorithm
void verlet(double dt, double *x, double *x_old, double *p, double *H, double *t){
	double tmp = *x;
	*x = 2*tmp-*x_old + acc(tmp)*dt*dt;  //verlet algorithm
	*p = (*x-*x_old)/(2.*dt);  //adjourn velocities (m=k=1)
	*x_old = tmp;  	//save old position
	*H = hamiltonian(*x, *p);
	*t = *t +dt;
	
}

int main(){

	//intial conditions
	double p0 = 0.;
	double x0 = 1.;
	
	//integration parameters
	double dt = 2.5; //time-step
	int N_timesteps = 10000; //number or time-step evolutions
	double max_time = N_timesteps*dt;
		
	//allocating memory
	double* x = (double*)malloc(sizeof(double));
	double* x_old = (double*)malloc(sizeof(double));
	double* p =(double*)malloc(sizeof(double));
	double* t =(double*)malloc(sizeof(double));
	double* H =(double*)malloc(sizeof(double));
	
	//file to save the data
	
	//initialization
	*x = x0;
	*p = p0;
	*x_old = cos(-dt);
	*H = hamiltonian(*x, *p);
	*t = 0.;
	
	//file to save the data
	char filename[150];
	
	sprintf(filename, "data/harmonic_oscillator_verlet_integrator_time%f_dt%f.txt", max_time, dt);
	
	//Creating file to save the data
	FILE * file = fopen(filename, "w");
	
	fprintf(file, "#time\tx\tp\tH\n");
	
	//integration
	for(int n = 0; n < N_timesteps; n++){
		fprintf(file, "%f\t%f\t%f\t%f\n", *t, *x, *p, *H);
		//non_symplectic_integrator(dt, x, p, H, t);
		//symplectic_integrator(dt, x, p, H, t);
		velocity_verlet(dt, x, p, H, t);
		//verlet(dt, x, x_old, p, H, t);
	}
	
	//freeing memory
	free(x);
	free(x_old);
	free(p);
	free(t);
	free(H);
	
	//closing the file
	fclose(file);
	

}
