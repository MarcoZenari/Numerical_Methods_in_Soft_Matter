// Test potential
double test(int i, int j){
	double out = 1/distance(i, j);
	return out;
}

//function to compute the total energy
double compute_tot_energy(){

	double energy = 0.;
	
	//Potential contribution 
	for (int i = 0; i < mySys.N_particles; i ++ ){
		for (int j = i+1; j < mySys.N_particles; j++){
			energy = energy + test(i, j);
		}
	}
	
	//Kinetic energy contribute (to be implemented)
	
	return energy;
}

//function to compute the total energy of a particle
double particle_energy(int i){

	double energy = 0.;
	
	//Potential contribution
	for (int j = 0; j < i; j++){
			energy = energy + test(i, j);
	}
	for (int j = i+1; j < mySys.N_particles; j++){
			energy = energy + test(i, j);
	}
		
	//Kinetic energy contribute (to be implemented)
	
	return energy;
}
