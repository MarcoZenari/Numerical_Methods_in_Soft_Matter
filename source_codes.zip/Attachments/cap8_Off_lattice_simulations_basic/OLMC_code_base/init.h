void read_input_file(){
	//open the input file
	FILE * input_file = fopen("input.dat", "r");
	
	//variables to read the input file
	char line[100];
	int i = 0;
	char * token;
	char * key = NULL;
	char * value = NULL;
	
	//reading line per line and saving key and value	
	while(fgets(line, sizeof(line), input_file) != NULL){

	      	token = strtok(line, " ");
	      	i = 0;
		while (token != NULL) {
			if (i == 0) key = token;
			if (i == 2) value = token;
			token = strtok(NULL, " ");
			i++;
		}    
		
	//saving value in the correct place by key
	if(strcmp("N_particles", key) == 0){mySys.N_particles = atoi(value); continue;}
	if(strcmp("N_sweeps", key) == 0){mySys.N_sweeps = atoi(value); continue; }
	if(strcmp("L_x", key) == 0){ mySys.L_x = atof(value); continue; } 
	if(strcmp("L_y", key) == 0){ mySys.L_y = atof(value); continue; }
	if(strcmp("L_z", key) == 0){ mySys.L_z = atof(value); continue; }
	if(strcmp("Temperature", key) == 0){ mySys.Temperature = atof(value); continue; }
	if(strcmp("Max_displacement", key) == 0){ mySys.Max_displacement = atof(value); continue; }
	if(strcmp("Seed", key) == 0){mySys.Seed = atoi(value); continue; }
    }
    
    //closing the file
    fclose(input_file);
}
