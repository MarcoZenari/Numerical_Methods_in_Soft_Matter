//Allocate the memory needed to store the particles
void allocate(){
	particles = (Particle*)malloc(mySys.N_particles*(sizeof(Particle)));
}

//Free the memory used to store the particles
void clean(){
	free(particles);
}

//Initialize the system at random
void initialization(){
	for (int i = 0; i < mySys.N_particles; i++){
		particles[i].x = uniform_intervall(0., mySys.L_x);
		particles[i].y = uniform_intervall(0., mySys.L_y);
		particles[i].z = uniform_intervall(0., mySys.L_z);			
	}
}

//print to std output the x,y,z positions of each particle (debugging porpouse)
void print_config(){
	for (int i = 0; i < mySys.N_particles; i++){
		printf("%d\t%f\t%f\t%f\n", i, particles[i].x, particles[i].y, particles[i].z);			
	}

}

//function to compute the minimal distance between two particles
double distance(int i, int j){
	//compute distance along each axes
	double dx = particles[j].x - particles[i].x;
	double dy = particles[j].y - particles[i].y;
	double dz = particles[j].z - particles[i].z;
	//apply box condition
	dx = dx - round(dx/mySys.L_x)*mySys.L_x;
	dy = dy - round(dy/mySys.L_y)*mySys.L_y;
	dx = dz - round(dz/mySys.L_z)*mySys.L_z;	
	//compute final distance
	double distance = sqrt(dx*dx +dy*dy +dz*dz);
	
	return distance;
}
