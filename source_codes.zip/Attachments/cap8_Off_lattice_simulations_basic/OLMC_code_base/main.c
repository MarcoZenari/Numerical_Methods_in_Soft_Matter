// Standard libraries
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Source file
#include "random.h"
#include "definitions.h"
#include "init.h"
#include "utils.h"
#include "energy.h"
#include "monte_carlo.h"

/* TO DO:
*/

int main(){
	//reading input file
	read_input_file();
	//initializing random generator
	srand(mySys.Seed);
	//allocating memory to store particles
	allocate();
	//initialize the system
	initialization();
	//print the initial configuration 
	//print_config();	//debugging purpouse
	//compute total energy of the initial configuration
	mySys.Energy = compute_tot_energy();
	//print initial total energy
	printf("energy:\t%f\n", mySys.Energy);
	//evolution of the system
	for (int t = 0; t<mySys.N_sweeps; t++){
		//monte carlo sweep
		monte_carlo_sweep();
		//print total energy
		printf("energy:\t%f\n", mySys.Energy);
	}
	//free the allocated memory
	clean();
	
	return 0;
}
