//Hard-sphere potential (add 1 if two partciles overlaps)
double hard_spheres(int i, int j){
	double out = 0;
	if(distance(i, j)<mySys.Radius){
		out = 1.;
	}
	return out;
}

//Compute total energy of the system
double compute_tot_energy(){
	double energy = 0.;
	
	//Potential contribution 
	for (int i = 0; i < mySys.N_particles; i ++ ){
		for (int j = i+1; j < mySys.N_particles; j++){
			energy = energy + hard_spheres(i, j);
		}
	}
	
	//Kinetic energy contribute (to be implemented)
	
	return energy;
}

//Compute energy of a particle
double particle_energy(int i){
	double energy = 0.;
	
	//Potential contribution
	for (int j = 0; j < i; j++){
			energy = energy + hard_spheres(i, j);
	}
	for (int j = i+1; j < mySys.N_particles; j++){
			energy = energy + hard_spheres(i, j);
	}
		
	//Kinetic energy contribute (to be implemented)
	
	return energy;
}

//Compute total density of the system
double compute_tot_density(){
	double out = 0;
	out = mySys.N_particles/(mySys.L_x * mySys.L_y * mySys.L_z);
	return out;
}
