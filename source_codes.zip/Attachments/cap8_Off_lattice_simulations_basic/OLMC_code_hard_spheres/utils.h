//Allocate the memory needed to store the particles
void allocate(){
	particles = (Particle*)malloc(mySys.N_particles*(sizeof(Particle)));
}

//Free the memory used to store the particles
void clean(){
	free(particles);
}

//Initialize the system based on the word code in input file
void initialization(){
	//Computing dimension of the system is density is given as input
	if (mySys.Density > 0 ){
		mySys.L_x = cbrt(mySys.N_particles/mySys.Density);
		mySys.L_y = cbrt(mySys.N_particles/mySys.Density);
		mySys.L_z = cbrt(mySys.N_particles/mySys.Density);
	}
	
	//Random initialization
	if (strcmp(mySys.Initialization, "random")==0){
		for (int i = 0; i < mySys.N_particles; i++){
			particles[i].x = uniform_intervall(0., mySys.L_x);
			particles[i].y = uniform_intervall(0., mySys.L_y);
			particles[i].z = uniform_intervall(0., mySys.L_z);			
		}
	}
	
	//Cubic lattice initialization
	if (strcmp(mySys.Initialization, "cubic_lattice")==0){
		int tmp = 0;
		int lattice_size =  ceil(cbrt(mySys.N_particles));
		double lattice_pace_x = mySys.L_x/(lattice_size+2.);
		double lattice_pace_y = mySys.L_y/(lattice_size+2.);
		double lattice_pace_z = mySys.L_z/(lattice_size+2.);
		 
		
		//Assigning particles on a cubic lattice
		
		for (int i = 1; i <= lattice_size+1; i++){
			for (int j = 1; j <=lattice_size+1; j++){
				for (int k = 1; k <= lattice_size+1; k++){
					particles[tmp].x = i*lattice_pace_x;
					particles[tmp].y = j*lattice_pace_y;
					particles[tmp].z = k*lattice_pace_z;
	
					tmp++;
					
					//checking if we have assigned all particles
					if(tmp == mySys.N_particles){
						break;
					}
				}
				if(tmp == mySys.N_particles){
						break;
				}
			}
			if(tmp == mySys.N_particles){
						break;
			}
		}
				
		//for debugging
		if (tmp!=(mySys.N_particles)){
			printf("Error in cubic_lattice initialization\n");
		}	
	}
}

//print to std output the x,y,z positions of each particle (debugging porpouse)
void print_config(){
	for (int i = 0; i < mySys.N_particles; i++){
		printf("%d\t%f\t%f\t%f\n", i, particles[i].x, particles[i].y, particles[i].z);			
	}

}

//function to compute the minimal distance between two particles
double distance(int i, int j){
	double dx = particles[j].x - particles[i].x;
	double dy = particles[j].y - particles[i].y;
	double dz = particles[j].z - particles[i].z;
	
	dx = dx - round(dx/mySys.L_x)*mySys.L_x;
	dy = dy - round(dy/mySys.L_y)*mySys.L_y;
	dx = dz - round(dz/mySys.L_z)*mySys.L_z;	
	
	double distance = sqrt(dx*dx +dy*dy +dz*dz);
	
	return distance;
}


//function to shorten a string given in input
void shortenString(char *str) {
    // Iterate through the characters in the string
    for (int i = 0; str[i] != '\0'; i++) {
        // If a white space character is found, truncate the string
        if (isspace(str[i])) {
            str[i] = '\0';
            break;
        }
    }
}
