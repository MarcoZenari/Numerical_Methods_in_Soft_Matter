// Standard libraries
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Source file
#include "random.h"
#include "definitions.h"
#include "utils.h"
#include "init.h"
#include "observables.h"
#include "monte_carlo.h"

/* TO DO:
*/

int main(){
	//read input file
	read_input_file();
	//initialize random generator
	srand(mySys.Seed);
	
	//For on the number of realizations
	for(int n = 0; n<mySys.N_realizations; n++){
		//allocate memory to store the particles
		allocate();
		//initialize the system
		initialization();
		//printing intial configuration for debugging
		print_config();
		//compute total energy
		mySys.Energy = compute_tot_energy();
		//compute density of the system (if not given as initial parameter)
		if (!(mySys.Density>0)){
			mySys.Density = compute_tot_density();
		}
		//creating output filename
		char filename[200];			
		sprintf(filename, "output/Hard_spheres_ic_%s_N_%d_density_%f_time_%d_displacement_%f_realization_%d.txt", mySys.Initialization, mySys.N_particles, mySys.Density, mySys.N_sweeps, mySys.Max_displacement, n);	
		//creating output file to store the data
		FILE * output_file = fopen(filename, "w");
		//printing initial condition
		fprintf(output_file, "%d\t%f\t%f\n", 0, mySys.Energy, mySys.Acceptance_ratio);
		//evolving the system and saving observables
		for (int t = 1; t < mySys.N_sweeps; t ++){
			monte_carlo_sweep();
			fprintf(output_file, "%d\t%f\t%f\n", t, mySys.Energy, mySys.Acceptance_ratio);
		}
		
		//deallocating memory	
		clean();
		fclose(output_file);
	}
	
	return 0;
}
