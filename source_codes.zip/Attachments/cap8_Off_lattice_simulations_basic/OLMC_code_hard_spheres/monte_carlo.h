//Function that execute a monte carlo move; modified for hard-spheres potential
int monte_carlo_move(){
	int out = 1; //return 1 if the move is accepted; 0 othrerwise
	int i = random_integer(0, mySys.N_particles-1); //sample a particle to displace
	
	//save old positions
	particles[i].old_x = particles[i].x;
	particles[i].old_y = particles[i].y;
	particles[i].old_z = particles[i].z;
	
	//compute initial energy
	double E0 = particle_energy(i);
	
	//move
	particles[i].x = particles[i].x + uniform_intervall(-mySys.Max_displacement, mySys.Max_displacement);
	particles[i].y = particles[i].y + uniform_intervall(-mySys.Max_displacement, mySys.Max_displacement);
	particles[i].y = particles[i].y + uniform_intervall(-mySys.Max_displacement, mySys.Max_displacement);
	
	//keeping the particle in the box
	particles[i].x = particles[i].x - floor(particles[i].x/mySys.L_x)*mySys.L_x;
	particles[i].y = particles[i].y - floor(particles[i].y/mySys.L_y)*mySys.L_y;
	particles[i].z = particles[i].z - floor(particles[i].z/mySys.L_z)*mySys.L_z;
	
	//computing the new energy
	double E1 = particle_energy(i);
	
	if(E1>E0){
		//invert the move (reject the move)
		particles[i].x = particles[i].old_x;
		particles[i].y = particles[i].old_y;
		particles[i].z = particles[i].old_z;
		out = 0; //not accepted
	}else{//otherwise keep the move 
		mySys.Energy = compute_tot_energy();  //adjourn total energy
	}
	//
	return out;
}


//Function that execute a monte carlo sweep
void monte_carlo_sweep(){
	int count = 0;
	for (int counter = 0; counter < mySys.N_particles; counter++){
		count = count + monte_carlo_move();	
	}
	mySys.Acceptance_ratio = (double)count/mySys.N_particles;  //adjour the Acceptance ratio
}


