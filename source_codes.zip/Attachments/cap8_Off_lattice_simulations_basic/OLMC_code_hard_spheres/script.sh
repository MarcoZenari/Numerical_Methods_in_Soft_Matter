#!/bin/bash

#compiling the code
make

# Create the input file
output_file="input.dat"

# Store the input parameters lists
initialization_list=('cubic_lattice')
density_list=("0.05" "0.3" "0.5" "1")
displacement_list=("0.01" "0.1" "0.5" "0.8" "1")

# For loop on parameters
for init in "${initialization_list[@]}"; do
	for rho in "${density_list[@]}"; do
		for d in "${displacement_list[@]}"; do

			#remove previous file if exists
			if [ -e "$output_file" ]; then
				rm "$output_file"
			fi
				
			#writing the input file
			echo "N_particles = 100" >> "$output_file"
			echo "N_sweeps = 30000" >> "$output_file"
			echo "Density = $rho" >> "$output_file"
			echo "Radius = 1" >> "$output_file"
			echo "Max_displacement = $d" >> "$output_file"
			echo "Seed = 22510112" >> "$output_file"
			echo "Initialization = $init" >> "$output_file"
			echo "N_realizations = 10" >> "$output_file"

			#running the code
			./executable.out
			
		done	
	done
done

#cleaning
make clean 



