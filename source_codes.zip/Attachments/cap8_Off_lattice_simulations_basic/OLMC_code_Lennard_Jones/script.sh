#!/bin/bash

#compiling the code
make

# Create the input file
output_file="input.dat"

# Store the input parameters lists
initialization_list=('cubic_lattice')
density_list=("0.1" "0.2" "0.3" "0.4" "0.5" "0.6" "0.7" "0.8" "0.9")
temperature_list=("2." "0.9")

# For loop on parameters
for init in "${initialization_list[@]}"; do
	for T in "${temperature_list[@]}"; do
		for rho in "${density_list[@]}"; do

			#remove previous file if exists
			if [ -e "$output_file" ]; then
				rm "$output_file"
			fi
				
			#writing the input file
			echo "N_particles = 100" >> "$output_file"
			echo "N_sweeps = 30000" >> "$output_file"
			echo "Density = $rho" >> "$output_file"
			echo "Temperature = $T" >> "$output_file"
			echo "sigma = 1." >> "$output_file"
			echo "eps = 1." >> "$output_file"
			echo "Max_displacement = 0.3" >> "$output_file"
			echo "Seed = 08041051" >> "$output_file"
			echo "Initialization = $init" >> "$output_file"
			echo "N_realizations = 5" >> "$output_file"

			#running the code
			./executable.out
			
		done	
	done
done

#cleaning
make clean 



