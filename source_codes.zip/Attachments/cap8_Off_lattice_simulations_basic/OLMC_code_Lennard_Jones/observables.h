//Lennard-Jones potential
double lennard_jones(int i, int j){
	double out = 0.;
	double r = distance(i, j);

	if (r<mySys.sigma_cut){
		out = 4.*mySys.eps*(pow(mySys.sigma/r, 12)-pow(mySys.sigma/r, 6));
	}

	return out;
}

//Compute total energy of the system
double compute_tot_energy(){
	double energy = 0.;
	
	//Potential contribution 
	for (int i = 0; i < mySys.N_particles; i ++ ){
		for (int j = i+1; j < mySys.N_particles; j++){
			energy = energy + lennard_jones(i, j);
		}
	}
	energy = energy + mySys.N_particles*mySys.u_tail;
	
	//Kinetic energy contribute (to be implemented)
	
	return energy;
}

//Compute energy of a particle
double particle_energy(int i){
	double energy = 0.;
	
	//Potential contribution
	for (int j = 0; j < i; j++){
			energy = energy + lennard_jones(i, j);
	}
	for (int j = i+1; j < mySys.N_particles; j++){
			energy = energy + lennard_jones(i, j);
	}
	energy = energy + mySys.u_tail;
		
	//Kinetic energy contribute (to be implemented)
	
	return energy;
}


//Compute total density of the system
double compute_tot_density(){
	double out = 0;
	out = mySys.N_particles/(mySys.L_x * mySys.L_y * mySys.L_z);
	return out;
}

//Compute Lennard-Jones derivative
double lennard_jones_derivative(int i, int j){
	double out = 0.;
	double r = distance(i, j);

	if (r<mySys.sigma_cut){
		out = 4.*mySys.eps*(-12.*pow(mySys.sigma/r, 13)+6.*pow(mySys.sigma/r, 7));
	}
	return out;
}


//copute Lennard-jones contribution to pressure
double lennard_jones_pressure_contribution(){
	double out = 0.;
	//double counter = 0.;
	for (int i = 0; i < mySys.N_particles; i ++ ){
		for (int j = i+1; j < mySys.N_particles; j++){
			//counter = counter+1.;
			out = out + distance(i,j)*lennard_jones_derivative(i, j);
		}
	}
	
	out = out;
	
	return out;
}


//Compute the total pressur of the system
double compute_pressure(){
	double volume = mySys.L_x*mySys.L_y*mySys.L_z;
	double pressure = mySys.N_particles*mySys.Temperature/volume - 1./(3.*volume)*lennard_jones_pressure_contribution() + mySys.P_tail;
	return pressure;
}





