// Constants
#define PI 3.14159265358979

// Struct Particle
typedef struct {
	//position of the particle at time t
	double x;
	double y;
	double z;
	
	//position of the particle at time t-1
	double old_x;
	double old_y;
	double old_z;
	
} Particle;

Particle * particles = NULL; //initializing to Null the pointer to the particles


// Struct system
typedef struct {
	int N_particles; //number of particles
	int N_sweeps; //number of Monte Carlo sweeps
	double L_x; //dimension of the system along x
	double L_y; //dimension of the system along y
	double L_z; //dimension of the system along z	
	double Temperature; //temperature of the system
	double sigma; //parameter of the Lennard-Jones model
	double eps; //parameter of the Lennard-Jones model
	double sigma_cut; //parameter of the Lennard-Jones model
	double u_tail; //parameter of the Lennard-Jones model
	double P_tail; //parameter of the Lennard-Jones model
	double Energy;  //energy of the system
	double Pressure; //Pressure of the system
	double Max_displacement; // Parameter for Monte Carlo move
	int Seed;	//seed to intialize random generator	
	char Initialization[20];	//codeword to choose initialization of the system
	double Density;	//density of the system
	double Acceptance_ratio; //store the acceptance ration in Monte Carlo sweep
	int N_realizations;  //Number of realizations of the system
} System;

System mySys;  //initializing the system



