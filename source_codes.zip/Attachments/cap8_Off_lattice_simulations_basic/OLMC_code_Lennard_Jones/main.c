// Standard libraries
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Source file
#include "random.h"
#include "definitions.h"
#include "utils.h"
#include "init.h"
#include "observables.h"
#include "monte_carlo.h"

/* TO DO:
*/

int main(){
	//read input file
	read_input_file();
	//initialize random generator
	srand(mySys.Seed);
	
	//printing in std-output parameters of simulation
	printf("N:\t%d\tN_sweeps:\t%d\trho:\t%f\tT:\t%f\n", mySys.N_particles, mySys.N_sweeps, mySys.Density, mySys.Temperature);
	
	//For on the number of realizations
	for(int n = 0; n<mySys.N_realizations; n++){
	
		//printing in std-output number of iterations
		printf("Iteration:\t%d\t/\t%d\n", n+1, mySys.N_realizations);
		//allocate memory to store the particles
		allocate();
		//initialize the system
		initialization();
		
				
		//compute total energy and pressure
		mySys.Energy = compute_tot_energy();
		mySys.Pressure = compute_pressure();
		
		
		//compute density of the system (if not given as initial parameter)
		if (!(mySys.Density>0)){
			mySys.Density = compute_tot_density();
		}
		
		
		//creating output filename
		char filename[200];			
		sprintf(filename, "output/Lennard_Jones_ic_%s_N_%d_density_%f_time_%d_Temperature_%f_displacement_%f_realization_%d.txt", mySys.Initialization, mySys.N_particles, mySys.Density, mySys.N_sweeps, mySys.Temperature, mySys.Max_displacement, n);	
		//creating output file to store the data
		FILE * output_file = fopen(filename, "w");
		//printing initial condition
		fprintf(output_file, "%d\t%f\t%f\t%f\n", 0, mySys.Energy, mySys.Pressure, mySys.Acceptance_ratio);
		
		//evolving the system and saving observables
		for (int t = 1; t < mySys.N_sweeps; t ++){
			monte_carlo_sweep();
			mySys.Pressure = compute_pressure();
			fprintf(output_file, "%d\t%f\t%f\t%f\n", t, mySys.Energy, mySys.Pressure, mySys.Acceptance_ratio);
		}
		
		//closing the file
		fclose(output_file);
		
		//deallocating memory	
		clean();
	
	}
	
	return 0;
}
