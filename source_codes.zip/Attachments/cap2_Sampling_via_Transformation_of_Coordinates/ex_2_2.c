#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "nmsm.h" //module with my costum functions

int main(){
	int N = 5000; //number of samples
	
	//initializing the random generator
	int seed = 13102023;
	srand(seed);
	
	//parameters of normal distribution
	double mu=3;
	double sigma=2;
	
	//allocating the memory to store the sample numbers
	double * x = (double *)malloc(2*sizeof(double));
	
	//opening the file to store the data
	FILE * file;
	file = fopen("data/gaussian_sample2.txt", "w");
	
	//header
	fprintf(file, "#x\ty\tn_sample = %d\n", N);
	
	//sampling
	for(int i=0; i<N; i++){
		x = box_muller(mu, sigma);
		fprintf(file, "%f\t%f\n", *x, *(x+1));
	}
	
	//freeing the memory	
	free(x);
	
	//closing the file
	fclose(file);

	return 0;
}
