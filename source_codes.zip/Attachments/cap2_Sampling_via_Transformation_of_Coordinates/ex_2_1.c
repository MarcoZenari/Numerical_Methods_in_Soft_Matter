#include <stdlib.h>
#include <stdio.h>

#include "nmsm.h"  //module with my costum functions

#define PI 3.14159265358979323846


int main(){
	int N = 10000; //number of sampling
	
	//Initialization of the random generator
	int seed = 12102023;
	srand(seed); 
	
	
	//variables for sampling
	double r1;
	double r2;
	
	//variables for radius and angle
	double r;
	double theta;
	

	//SAMPLING THE WRONG WAY
	FILE * file_wrong;
	file_wrong = fopen("data/disk_sample_wrong.txt", "w");
	
	//header
	fprintf(file_wrong, "#radius\tangle\tn_sample = %d \n", N);
	
	
	
	for(int i=0; i<N; i++){
		//sampling two uniform variables
		r1 = uniform();
		r2 = uniform();
		
		//modifing the values
		r = r1;
		theta = 2*PI*r2;
		
		//saving the data to file
		fprintf(file_wrong, "%f\t%f\n", r, theta);
	}
	fclose(file_wrong);
	
	
	//SAMPLING THE CORRECT WAY
	FILE * file_right;
	file_right = fopen("data/disk_sample_right.txt", "w");
	
	//header
	fprintf(file_right, "#radius\tangle\tn_sample = %d \n", N);
	
	
	for(int i=0; i<N; i++){
		//sampling two uniform variables
		r1 = uniform();
		r2 = uniform();
		
		//modifing the values
		r = sqrt(r1);
		theta = 2*PI*r2;
		
		//saving the data to file
		fprintf(file_right, "%f\t%f\n", r, theta);
	}
	fclose(file_right);
	
	
	
	return 0;
}
