#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "nmsm.h" //module with costum functions


//the function from wich we wanto to sample with rejection method
double f(double x, double * fPar);

//the function used to limit in the rejection method
double g(double x, double * gPar);

//the inverse function of the cdf of g(x)
double inv_F(double y, double * inv_FPar);


int main(){
	//initialize random generator
	int seed = 17102023;
	srand(seed);
	
	int N = 100000; //number of darts
	
	double c = 10; //costant for sup limit
	double p = 0.1; //parameter for the function
	
	int max_par = 10; //numero massimo di parametri per funzione
	
	//initializating the pointer to the parameters of the function
	double * fPar = (double *)malloc(max_par*sizeof(double));
	double * gPar = (double *)malloc(max_par*sizeof(double));
	double * inv_FPar = (double *)malloc(max_par*sizeof(double));
	
	//assigning the parameters
	*gPar = p;
	*inv_FPar = p;
	
	//file to store the data
	FILE * file;
	file = fopen("data/data_for_importance_sampling.txt", "w");
	
	
	
	//header
	fprintf(file, "#c=%f\tp=%f\tN=%d\n", c, p, N);
	
	//cicle on the darts
	for(int i = 0; i<N; i++){
		//saving in the file the samples
		fprintf(file, "%f\n", rejection_method_sampling(f, g, inv_F, c, fPar, gPar, inv_FPar));

	}
	
	//closing the file
	fclose(file);
	
	//freeing memory
	free(fPar);
	free(gPar);
	free(inv_FPar);
	
	
	return 0;
}



//the function from wich we wanto to sample with rejection method
double f(double x, double *fPar){
	double out = 2./sqrt(PI)*exp(-x*x);
	return(out);
}

//the function used to limit in the rejection method
double g(double x, double *gPar){
	double out;
	double p = *gPar;
	double A = 2*p/(2*p*p+1);
	if(x>=0 && x<=p){
		out = A;
	}else if (x>p){
		out = A/p*x*exp(-x*x+p*p);
	}else{
		printf("Invalid domain input in g(x)\n");
	}
	return out; 
}


//the inverse function of the cdf of g(x)
double inv_F(double y, double * inv_FPar){
	double out;
	double p = *inv_FPar;
	double A = 2*p/(2*p*p+1);
	double k = A*p + A/(p*2);
	if (y>=0 && y<=A*p){
		out = y/A;
	}else if(y>A*p && y<=1){
		out = sqrt(p*p-log(2*p/A*(k-y)));
	}else{
	printf("Invalid input in inv_F\n");
	}
	return out;
}


