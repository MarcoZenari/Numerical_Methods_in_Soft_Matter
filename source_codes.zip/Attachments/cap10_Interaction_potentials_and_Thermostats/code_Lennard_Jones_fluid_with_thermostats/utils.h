//Allocate the memory needed to store the particles
void allocate(){
	particles = (Particle*)malloc(mySys.N_particles*(sizeof(Particle)));
}

//Free the memory used to store the particles
void clean(){
	free(particles);
}


//print to std output the x,y,z positions of each particle (debugging porpouse)
void print_config(){
	for (int i = 0; i < mySys.N_particles; i++){
		printf("%d\t%f\t%f\t%f\t%f\t%f\t%f\n", i, particles[i].x, particles[i].y, particles[i].z, particles[i].v_x, particles[i].v_y, particles[i].v_z);			
	}

}


//function to compute the minimal distance between two particles
double distance(int i, int j){
	double dx = particles[j].x - particles[i].x;
	double dy = particles[j].y - particles[i].y;
	double dz = particles[j].z - particles[i].z;
	
	dx = dx - round(dx/mySys.L_x)*mySys.L_x;
	dy = dy - round(dy/mySys.L_y)*mySys.L_y;
	dz = dz - round(dz/mySys.L_z)*mySys.L_z;	
	
	double distance = sqrt(dx*dx +dy*dy +dz*dz);
	
	return distance;
}


//Compute all the distances between particles as test
void test_distances(){

	//Potential contribution 
	for (int i = 0; i < mySys.N_particles; i ++ ){
		for (int j = 0; j < mySys.N_particles; j++){
			printf("Distance between %d and %d is: %f \n", i, j, distance(i,j));
		}
	}


}


//function to shorten a string given in input
void shortenString(char *str) {
    // Iterate through the characters in the string
    for (int i = 0; str[i] != '\0'; i++) {
        // If a white space character is found, truncate the string
        if (isspace(str[i])) {
            str[i] = '\0';
            break;
        }
    }
}

//Lennard-Jones potential
double lennard_jones(int i, int j){
	double out = 0.;
	double r = distance(i, j);
	
	if (r<mySys.rc){
		out = 4.*mySys.eps*(pow(mySys.sigma/r, 12)-pow(mySys.sigma/r, 6)) -  4.*mySys.eps*(pow(mySys.sigma/mySys.rc, 12)-pow(mySys.sigma/mySys.rc, 6));
	}
	
	return out;
}

//Compute total energy of the system
double compute_tot_energy(){
	double pot_energy = 0.;
	double kin_energy = 0.;
	
	//Potential contribution 
	for (int i = 0; i < mySys.N_particles; i ++ ){
		for (int j = i+1; j < mySys.N_particles; j++){
			pot_energy = pot_energy + lennard_jones(i, j);
		}
	}
	mySys.Potential_Energy = pot_energy;
	
	//Kinetic energy contribution
	for (int i = 0; i<mySys.N_particles; i++){
		kin_energy = kin_energy + 1./2. * mySys.m * (particles[i].v_x*particles[i].v_x+particles[i].v_y*particles[i].v_y+particles[i].v_z*particles[i].v_z);
	}
	mySys.Kinetic_Energy = kin_energy;
	
	return pot_energy+kin_energy;
}


//Compute total density of the system
double compute_tot_density(){
	double out = 0;
	out = mySys.N_particles/(mySys.L_x * mySys.L_y * mySys.L_z);
	return out;
}

//Compute Lennard-Jones derivative
double lennard_jones_derivative(double r){
	double out = 0.;
	out = 4.*mySys.eps*(-12.*pow(mySys.sigma/r, 13)+6.*pow(mySys.sigma/r, 7));
	return out;
}

//compute the forces acting on particle i along direction j
double forces(int i, int j){
	double out = 0.;
	double r = 0.;
	double V_grad = 0.;
	double delta = 0.;
	for (int k = 0; k<mySys.N_particles; k++){
		if (i!=k){
			if (j==0){
				delta = particles[k].x - particles[i].x;			
				delta = delta - round(delta/mySys.L_x)*mySys.L_x;				
				r = distance(i, k);
				if (r<mySys.rc){
					V_grad= lennard_jones_derivative(r);
					out = out + V_grad*delta/r;
				}
			}
			else if (j ==1){
				delta = particles[k].y - particles[i].y;			
				delta = delta - round(delta/mySys.L_y)*mySys.L_y;				
				r = distance(i, k);
				if (r<mySys.rc){
					V_grad= lennard_jones_derivative(r);
					out = out + V_grad*delta/r;
				}
			}
			else{
				delta = particles[k].z - particles[i].z;			
				delta = delta - round(delta/mySys.L_z)*mySys.L_z;				
				r = distance(i, k);
				if (r<mySys.rc){
					V_grad= lennard_jones_derivative(r);
					out = out + V_grad*delta/r;
				}
			}
		}
	}
	
	return out;
}


//Function that execute a monte carlo move; modified for hard-spheres potential
int monte_carlo_move(){
	int out = 1; //return 1 if the move is accepted; 0 otherwise
	int i = random_integer(0, mySys.N_particles-1); //sample a particle to displace
	
	//save old positions
	particles[i].x_old = particles[i].x;
	particles[i].y_old = particles[i].y;
	particles[i].z_old = particles[i].z;
	
	//compute initial energy
	double E0 = mySys.Energy;
	
	//move
	particles[i].x = particles[i].x + uniform_intervall(-mySys.Max_displacement, mySys.Max_displacement);
	particles[i].y = particles[i].y + uniform_intervall(-mySys.Max_displacement, mySys.Max_displacement);
	particles[i].z = particles[i].z + uniform_intervall(-mySys.Max_displacement, mySys.Max_displacement);
	
	//keeping the particle in the box
	particles[i].x = particles[i].x - floor(particles[i].x/mySys.L_x)*mySys.L_x;
	particles[i].y = particles[i].y - floor(particles[i].y/mySys.L_y)*mySys.L_y;
	particles[i].z = particles[i].z - floor(particles[i].z/mySys.L_z)*mySys.L_z;
	
	//computing the new energy
	double E1 = compute_tot_energy();
	
	//METROPOLIS acceptance ratio
	if(E1>E0){
		double r = uniform();		
		if(r > exp(-(E1-E0)/mySys.Temperature)){
			//invert the move (reject the move)
			particles[i].x = particles[i].x_old;
			particles[i].y = particles[i].y_old;
			particles[i].z = particles[i].z_old;
			out = 0;
		}	
		else{//otherwise keep the move 
			//adjourn total energy 
			mySys.Energy = E1;
		}
	}else{//otherwise keep the move 
		//adjourn total energy 
		mySys.Energy = E1;
	}
	return out;
}


//Function that execute a monte carlo sweep
void monte_carlo_sweep(){
	int count = 0;
	mySys.Energy = compute_tot_energy();
	for (int counter = 0; counter < mySys.N_particles; counter++){
		count = count + monte_carlo_move();	
	}
}


//number of pair interactions
int N_pairs(){
	int out = 0;
	//out = ceil(mySys.N_particles*(mySys.N_particles-1)/2);
	out = mySys.N_particles*mySys.N_particles;
	return out;
}

//list distances
double * list_distances(){
	double * out = (double*)malloc(N_pairs()*sizeof(double));
	int counter = 0;
	for (int i = 0; i<mySys.N_particles; i++){
		for (int j = 0; j< mySys.N_particles; j++){
			*(out + counter) = distance(i, j);
			counter++;
		}
	}
	if (counter!= N_pairs()){
		printf("Error in list distances\n");
	}
	
	return out;
}

//number of bins of g(r)
int N_bins_g_r(double dr){
	int out = ceil(mySys.L_x/2./dr);
	return out;
}


//function to compute the radial distribution function
double * g_r(double dr, int N_bins){

	double * out = (double*)malloc(N_bins*sizeof(double));
	double * distances = list_distances();
	int N_p = N_pairs();
	double r_min = 0;
	double r_max = 0;
	
	for (int k = 0; k<N_bins; k++){
		r_min = k*dr+1e-9;
		r_max = r_min+dr;
		for (int i  = 0; i<N_p; i++){
			if ((*(distances + i)<r_max) &&	(*(distances + i)>r_min)){
				*(out + k) = *(out + k) + 1;
			}
		}
		
		*(out + k) = *(out + k)/(mySys.N_particles*mySys.Density*4./3.*PI*(r_max*r_max*r_max-r_min*r_min*r_min));	
	}
	
	return out;
}


//Initialize the system based on the word code in input file
void initialization(){
	printf("\t--> Initializing the system\n");
	//Computing dimension of the system is density is given as input
	if (mySys.Density > 0 ){
	
		mySys.L_x = cbrt(mySys.N_particles/mySys.Density);
		mySys.L_y = cbrt(mySys.N_particles/mySys.Density);
		mySys.L_z = cbrt(mySys.N_particles/mySys.Density);
	}
	
	//compute density of the system (if not given as initial parameter)
	if (!(mySys.Density>0)){
		mySys.Density = compute_tot_density();
	}
	
	
	if (mySys.dr>0){
		mySys.N_bins = N_bins_g_r(mySys.dr);
		mySys.g_d_r = (double*)malloc(mySys.N_bins*sizeof(double)); 
	}
	
	//Random initialization
	if (strcmp(mySys.Initialization, "random")==0){
		for (int i = 0; i < mySys.N_particles; i++){
			particles[i].x = uniform_intervall(0., mySys.L_x);
			particles[i].y = uniform_intervall(0., mySys.L_y);
			particles[i].z = uniform_intervall(0., mySys.L_z);			
		}
	}
	
	//Cubic lattice initialization
	if (strcmp(mySys.Initialization, "cubic_lattice+MC")==0){
		int tmp = 0;
		int lattice_size =  ceil(cbrt(mySys.N_particles));
		double lattice_pace_x = mySys.L_x/(lattice_size+2.);
		double lattice_pace_y = mySys.L_y/(lattice_size+2.);
		double lattice_pace_z = mySys.L_z/(lattice_size+2.);
		 
		
		//Assigning particles on a cubic lattice
		
		for (int i = 1; i <= lattice_size+1; i++){
			for (int j = 1; j <=lattice_size+1; j++){
				for (int k = 1; k <= lattice_size+1; k++){
				
					//particle initialization
					particles[tmp].x = i*lattice_pace_x;
					particles[tmp].y = j*lattice_pace_y;
					particles[tmp].z = k*lattice_pace_z;
						
					tmp++;
					
					//checking if we have assigned all particles
					if(tmp == mySys.N_particles){
						break;
					}
				}
				if(tmp == mySys.N_particles){
						break;
				}
			}
			if(tmp == mySys.N_particles){
						break;
			}
		}
				
		//for debugging
		if (tmp!=(mySys.N_particles)){
			printf("Error in cubic_lattice initialization\n");
		}
		
		// Running a Monte Carlo evolution to reach equilibrium distribution
		//evolving the system and saving observables
		if (mySys.N_eq_steps <20){
			mySys.N_eq_steps = 20;
		}
		
		for (int t = 1; t < mySys.N_eq_steps; t ++){
			monte_carlo_sweep();
		}
		
		
		//Initializing velocities
		for (int j = 0; j < mySys.N_particles; j ++){
			//NB: Box mullers return an array of 2 gaussian samples
			double * x1 = box_muller(0., sqrt(mySys.Bath_temperature/mySys.m));
			double * x2 = box_muller(0., sqrt(mySys.Bath_temperature/mySys.m));
			particles[j].v_x = x1[0] ;
			particles[j].v_y = x1[1];
			particles[j].v_z = x2[0];
		}
		
		
		//initializing forces
		for (int i = 0; i < mySys.N_particles; i ++){
			particles[i].f_x = forces(i, 0);
			particles[i].f_y = forces(i, 1);
			particles[i].f_z = forces(i, 2);
		}
				
	}
}
