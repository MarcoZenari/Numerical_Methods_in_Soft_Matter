void read_input_file(){
	//open the input file
	FILE * input_file = fopen("input.dat", "r");

	//variables to read the input file
	char line[100];
	int i = 0;
	char * token;
	char * key = NULL;
	char * value = NULL;

	//read line per line and store value and key	
	while(fgets(line, sizeof(line), input_file) != NULL){

	      	token = strtok(line, " ");
	      	i = 0;
		while (token != NULL) {
			if (i == 0) key = token;
			if (i == 2) value = token;
			token = strtok(NULL, " ");
			i++;
		}     

		//store values by key
		if(strcmp("N_particles", key) == 0){mySys.N_particles = atoi(value); continue;}
		if(strcmp("N_steps", key) == 0){mySys.N_steps = atoi(value); continue; }
		if(strcmp("dt", key) == 0){ mySys.dt = atof(value); continue; } 
		if(strcmp("N_es_steps", key) == 0){mySys.N_eq_steps = atoi(value); continue;}
		if(strcmp("Density", key) == 0){mySys.Density = atof(value); continue; }
		if(strcmp("dr", key) == 0){mySys.dr = atof(value); continue; }
		if(strcmp("Mass", key) == 0){mySys.m = atof(value); continue; }
		if(strcmp("rc", key) == 0){ mySys.rc = atof(value); continue; } 
		if(strcmp("Max_displacement", key) == 0){ mySys.Max_displacement = atof(value); continue; } 
		if(strcmp("L_x", key) == 0){ mySys.L_x = atof(value); continue; } 
		if(strcmp("L_y", key) == 0){ mySys.L_y = atof(value); continue; }
		if(strcmp("L_z", key) == 0){ mySys.L_z = atof(value); continue; }
		if(strcmp("Temperature", key) == 0){ mySys.Bath_temperature = atof(value); continue; }
		if(strcmp("sigma", key) == 0){ mySys.sigma = atof(value); continue; }
		if(strcmp("eps", key) == 0){ mySys.eps = atof(value); continue; }
		if(strcmp("Seed", key) == 0){mySys.Seed = atoi(value); continue; }
		if(strcmp("Initialization", key) == 0){strcpy(mySys.Initialization, value); shortenString(mySys.Initialization); continue; }
		if(strcmp("N_realizations", key) == 0){mySys.N_realizations = atoi(value); continue; }
		if(strcmp("Frequency", key) == 0){mySys.omega = atof(value); continue; }
    	}
    
	fclose(input_file);




}
