//module with the functions implemented for the thermostats


// Kinetic Temperature T_k at time t
void kinetic_temperature(){
	double out = 0.;
	
	for(int i = 0; i<mySys.N_particles; i++){
		out = out + (particles[i].v_x*particles[i].v_x + particles[i].v_y*particles[i].v_y + particles[i].v_z*particles[i].v_z);
	}
	out = out*mySys.m/(3.*mySys.N_particles);
	
	//updating kinetic temperature of the system
	mySys.Temperature = out;
}


// Velocity rescaling
void velocity_rescaling(){

	double lambda = sqrt(mySys.Bath_temperature/mySys.Temperature);
	
	for (int i = 0; i<mySys.N_particles; i++){
		particles[i].v_x = lambda*particles[i].v_x;
		particles[i].v_y = lambda*particles[i].v_y;
		particles[i].v_z = lambda*particles[i].v_z;
	}	
}

// Andersen thermostat
void andersen_thermostat(){
	double prob = mySys.dt*mySys.omega;
	for (int i = 0; i<mySys.N_particles; i++){
		if( uniform() < prob){
			double * x1 = box_muller(0., sqrt(mySys.Bath_temperature/mySys.m));
			double * x2 = box_muller(0., sqrt(mySys.Bath_temperature/mySys.m));
			particles[i].v_x = x1[0] ;
			particles[i].v_y = x1[1];
			particles[i].v_z = x2[0];
		}
	}
}

