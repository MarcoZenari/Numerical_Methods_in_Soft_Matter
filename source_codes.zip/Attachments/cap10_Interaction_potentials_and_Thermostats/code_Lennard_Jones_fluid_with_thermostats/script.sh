#!/bin/bash

#compiling the code
make

# Create the input file
output_file="input.dat"

# Store the input parameters lists
N_list=("200" "175" "150" "125" "100" "75" "50")

# For loop on parameters
for N in "${N_list[@]}"; do

	#remove previous file if exists
	if [ -e "$output_file" ]; then
		rm "$output_file"
	fi
		
	#writing the input file
	
	echo "N_particles = $N" >> "$output_file"
	echo "N_steps = 5000" >> "$output_file"
	echo "N_eq_steps = 100" >> "$output_file"
	echo "dt = 0.01" >> "$output_file"
	echo "Temperature = 2." >> "$output_file"
	echo "sigma = 1." >> "$output_file"
	echo "eps = 1." >> "$output_file"
	echo "Max_displacement = 0.3" >> "$output_file"
	echo "Seed = 12152705" >> "$output_file"
	echo "Initialization = cubic_lattice+MC" >> "$output_file"
	echo "N_realizations = 1" >> "$output_file"
	echo "Mass = 1." >> "$output_file"
	echo "L_x = 10" >> "$output_file"
	echo "L_y = 10" >> "$output_file"
	echo "L_z = 10" >> "$output_file"
	echo "rc = 3.0" >> "$output_file"
	echo "Frequency = 10." >> "$output_file"

	#running the code
	./executable.out
	
done

#cleaning
make clean 



