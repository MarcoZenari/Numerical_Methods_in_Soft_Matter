//sample a uniform number between 0 and 1
double uniform(){
	//rand() samples an integer between 0 and RAND_MAX from random generator of stdlib
	double out = (double)rand()/(RAND_MAX+1.);
	return out;
}

//sample a uniform number between inf and sup
double uniform_intervall(double inf, double sup){
	//reparametrize the uniform sample U[0,1] in U[inf, sup]
	double out = inf + (sup - inf)*uniform();
	return out;
}

//sample a random integer between inf and sup
int random_integer(int inf, int sup){
	int out = 0;
	out =(rand()+inf)%(sup-inf+1); //extract a random integer between inf and sup
	return out;
}

double * box_muller(double mu, double sigma){
	double * x = (double *)malloc(2*sizeof(double)); //creating a pointer allocation memory
	double u1 = uniform(); //sampling a uniform rv
	double u2 = uniform(); //sampling a uniform rv
	//using box-muller transformations to obtain two normal gaussian rv
	x[0] = sqrt(-2*log(u1))*cos(2*PI*u2);
	x[1] = sqrt(-2*log(u1))*sin(2*PI*u2); 
	//reparametrize the rv to a N[mu, sigma^2]
	x[0] = mu + x[0]*sigma;
	x[1] = mu + x[1]*sigma;
	//returning the pointer
	return x;
}

