void velocity_verlet_step(){
	//saving old positions and forces
	for (int i = 0; i < mySys.N_particles; i++){
		particles[i].x_old = particles[i].x;
		particles[i].y_old = particles[i].y;	
		particles[i].z_old = particles[i].z;
		
		particles[i].f_x_old = particles[i].f_x;
		particles[i].f_y_old = particles[i].f_y;
		particles[i].f_z_old = particles[i].f_z;				
	}
	
	//updating positions
	for (int i = 0; i<mySys.N_particles; i++){
		//updating positions
		particles[i].x = particles[i].x_old + particles[i].v_x * mySys.dt + particles[i].f_x_old*mySys.dt * mySys.dt /(2.*mySys.m);
		particles[i].y = particles[i].y_old + particles[i].v_y * mySys.dt + particles[i].f_y_old*mySys.dt * mySys.dt /(2.*mySys.m);;	
		particles[i].z = particles[i].z_old + particles[i].v_z * mySys.dt + particles[i].f_z_old*mySys.dt * mySys.dt /(2.*mySys.m);;	
		
		//keeping the particle in the box
		particles[i].x = particles[i].x - floor(particles[i].x/mySys.L_x)*mySys.L_x;
		particles[i].y = particles[i].y - floor(particles[i].y/mySys.L_y)*mySys.L_y;
		particles[i].z = particles[i].z - floor(particles[i].z/mySys.L_z)*mySys.L_z;	
	}
	
	
	//updating velocities
	for (int i = 0; i<mySys.N_particles; i++){
		//computing new forces
		particles[i].f_x = forces(i, 0);
		particles[i].f_y = forces(i, 1);
		particles[i].f_z = forces(i, 2);
		
		//updating velocities
		particles[i].v_x = particles[i].v_x + (particles[i].f_x_old + particles[i].f_x)* mySys.dt/(2.* mySys.m);
		particles[i].v_y = particles[i].v_y + (particles[i].f_y_old + particles[i].f_y) * mySys.dt /(2.*mySys.m);	
		particles[i].v_z = particles[i].v_z + (particles[i].f_z_old + particles[i].f_z)* mySys.dt /(2.*mySys.m);		
	}
}
