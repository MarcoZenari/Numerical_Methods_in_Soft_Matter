#!/bin/bash

#compiling the code
make

# Create the input file
output_file="input.dat"

# Store the input parameters lists
rad_cutoff_list=("1.0" "1.2" "1.4" "1.6" "1.8" "2.0" "2.2" "2.4" "2.6" "2.8" "3.0" "3.2" "3.4" "3.6" "3.8" "4.0" "4.2")
temperature_list=("2." "0.9")

# For loop on parameters
for rc in "${rad_cutoff_list[@]}"; do

	#remove previous file if exists
	if [ -e "$output_file" ]; then
		rm "$output_file"
	fi
		
	#writing the input file
	
	echo "N_particles = 200" >> "$output_file"
	echo "N_steps = 1000" >> "$output_file"
	echo "N_eq_steps = 100" >> "$output_file"
	echo "dt = 0.01" >> "$output_file"
	echo "dr = 0.01" >> "$output_file"
	echo "Temperature = 1." >> "$output_file"
	echo "sigma = 1." >> "$output_file"
	echo "eps = 1." >> "$output_file"
	echo "Max_displacement = 0.3" >> "$output_file"
	echo "Seed = 12152705" >> "$output_file"
	echo "Initialization = cubic_lattice+MC" >> "$output_file"
	echo "N_realizations = 1" >> "$output_file"
	echo "Mass = 1." >> "$output_file"
	echo "L_x = 10" >> "$output_file"
	echo "L_y = 10" >> "$output_file"
	echo "L_z = 10" >> "$output_file"
	echo "rc = $rc" >> "$output_file"

	#running the code
	./executable.out
	
done

#cleaning
make clean 



