// Struct Particle
typedef struct {
	//position of the particle at time t
	double x;
	double y;
	double z;
		
	//velocities of the particles at time t
	double v_x;
	double v_y;
	double v_z;
	
	//forces acting on particle at time t
	double f_x;
	double f_y;
	double f_z;
	
	//forces acting on particle at time t-1
	double f_x_old;
	double f_y_old;
	double f_z_old;
	
	//position of the particle at time t-1
	double x_old;
	double y_old;
	double z_old;
	
} Particle;

Particle * particles = NULL; //initializing to Null the pointer to the particles


// Struct system
typedef struct {
	int N_particles; //number of particles
	int N_steps; //number of Monte Carlo sweeps
	int N_eq_steps; //number of steps used to reach equilibrium position
	double Max_displacement; //parameter used in MC to reach equilibrium
	double dr; //parameter to compute radial distribution function
	int N_bins; //parameter to compute radial distribution function
	double * g_d_r; //radial distribution function
	double dt; //duration of time step
	double L_x; //dimension of the system along x
	double L_y; //dimension of the system along y
	double L_z; //dimension of the system along z	
	double m; //mass of the particles
	double Temperature; //temperature of the system
	double sigma; //parameter of the Lennard-Jones model
	double eps; //parameter of the Lennard-Jones model
	double rc; //parameter of the Lennard-Jones model
	double Energy;  //energy of the system
	double Potential_Energy; //potential Energy of the system
	double Kinetic_Energy; //Kinetic energy of the system
	double Pressure; //Pressure of the system
	int Seed;	//seed to intialize random generator	
	char Initialization[20];	//codeword to choose initialization of the system
	double Density;	//density of the system
	int N_realizations;  //Number of realizations of the system
} System;

System mySys;  //initializing the system



