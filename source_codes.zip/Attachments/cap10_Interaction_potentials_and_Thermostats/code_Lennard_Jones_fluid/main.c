// Standard libraries
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define PI 3.14159265358979323846

// Source file
#include "random.h"
#include "definitions.h"
#include "utils.h"
#include "init.h"
#include "integrator.h"



int main(){
	//read input file
	read_input_file();
	//initialize random generator
	srand(mySys.Seed);
	
	//printing in std-output parameters of simulation
	printf("N:\t%d\tN_steps:\t%d\tT:\t%f\trc:%f\n", mySys.N_particles, mySys.N_steps, mySys.Temperature, mySys.rc);
	
	
	//For on the number of realizations
	for(int n = 0; n<mySys.N_realizations; n++){
	
		//printing in std-output number of iterations
		printf("Iteration:\t%d\t/\t%d\n", n+1, mySys.N_realizations);
		//allocate memory to store the particles
		allocate();
		//initialize the system
		initialization();
				
		//compute total energy and pressure
		mySys.Energy = compute_tot_energy();
		
		//creating outputs filename
		char filename1[200];			
		sprintf(filename1, "output/Lennard_Jones_ic_%s_N_%d_density_%f_time_%d_Temperature_%f_rc_%f_realization_%d.txt", mySys.Initialization, mySys.N_particles, mySys.Density, mySys.N_steps, mySys.Temperature, mySys.rc, n);	
		//creating output file to store the data
		FILE * output_file1 = fopen(filename1, "w");
		//printing initial condition
		fprintf(output_file1, "%d\t%f\t%f\t%f\n", 0, mySys.Potential_Energy, mySys.Kinetic_Energy, mySys.Energy);
		
		
		printf("\t--> Evolving the system\n");
		
		//evolving the system and saving observables
		double * gdr_tmp = (double*)malloc(mySys.N_bins*sizeof(double)); 
		
		for (int t = 1; t <= mySys.N_steps; t ++){
		
			velocity_verlet_step();
			
			//update radial distribution function
			gdr_tmp = g_r(mySys.dr, mySys.N_bins);
			
			for (int k = 0; k<mySys.N_bins; k++){
				*(mySys.g_d_r+k) = *(mySys.g_d_r+k) + *(gdr_tmp+k);
			}
			
			
			t = t + mySys.dt; //adjourning time
			
			//Saving energy time-series
			mySys.Energy = compute_tot_energy();
			fprintf(output_file1, "%d\t%f\t%f\t%f\n", t, mySys.Potential_Energy, mySys.Kinetic_Energy, mySys.Energy);
		}
		
		free(gdr_tmp);
		
		//closing the file
		fclose(output_file1);
		
		// SAVING AVERAGE RADIAL DISTRIBUTION FUNCTION
	
		char filename2[200];			
		sprintf(filename2, "output/GdR_Lennard_Jones_ic_%s_N_%d_density_%f_time_%d_Temperature_%f_rc_%f_realization_%d.txt", mySys.Initialization, mySys.N_particles, mySys.Density, mySys.N_steps, mySys.Temperature, mySys.rc, n);	
		//creating output file to store the data
		FILE * output_file2 = fopen(filename2, "w");
		
		//Computing Radial Distribution Function
		printf("\t --> Saving Radial Distribution Function\n");
		for (int k = 0; k<mySys.N_bins; k++){
			*(mySys.g_d_r+k) = *(mySys.g_d_r+k)/mySys.N_steps;
			fprintf(output_file2, "%f\t%f\n", k*mySys.dr+mySys.dr/2., *(mySys.g_d_r+k));
		}
		
		//closing the file
		fclose(output_file2);
					
		//deallocating memory	
		clean();
	}
	
	return 0;
}
