#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "nmsm.h" //module with costum functions

//function used in importance sampling
double g(double x, double * gPar);

//function to integrate
double f(double x);

//functio to use in rejection method sampling
double g1(double x, double *g1Par);

//inverse cdf for rejection method
double inv_F(double y, double *inv_FPar);


int main(){
	//initializing the random generator
	int seed = 17102023;
	srand(seed);
	
	//number of samples used
	int N = 1000;
	
	//integration intervall
	double inf = 0; 
	double sup = PI/2;
	
	
	int max_par = 10; //maximum number of parameters in a function
	
	double * g1Par = (double *)malloc(max_par*sizeof(double));
	double * inv_FPar = (double *)malloc(max_par*sizeof(double));
	double * gPar =  (double *)malloc(max_par*sizeof(double));
	
	double I = 0; //to compute the integral
	
	double x ; //variable to save the sample
	
	double c = 1.5; //constant for rejection method
	
	
	for(int j=0; j<N; j++){
		
		//sample x with with rejection method
		x = rejection_method_sampling(g, g1, inv_F, c, gPar, g1Par, inv_FPar);
		
		
		//adjourning the integral
		I = I + f(x)/g(x, gPar);
	}
	
	I = I/N;
	
	printf("The integral estimated with importance sampling with N=%d points is: \n%f\n", N, I);
	
	//Freeing the memory
	free(g1Par);
	free(inv_FPar);
	free(gPar);
	return 0;
}


//function to integrate
double f(double x){
	double out = 0;
	out = cos(x);
	return out;
}

//function used in importance sampling
double g(double x, double *gPar){
	double out = 0;
	double b = -12./(PI*PI*PI);
	double a = 3./(PI);
	out = a+b*x*x;
	return out;
}


//functio to use in rejection method sampling
double g1(double x, double *g1Par){
	double out  = 1.-(4/PI-8/(PI*PI))*x;
	return out;
}

//inverse cdf for rejection method
double inv_F(double y, double *inv_FPar){
	double b = -12./(PI*PI*PI);
	double a = 3./(PI);
	double out;
	out = 2/b*(a-y);
	return out;
}

