#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "nmsm.h" //module with costum functions

//function that enters in the definition of the function to integrate
double g(double x);

//function to be integrated
double f(double x, double * fPar);

int main(){
	//initializing the random generator
	int seed = 17102023;
	srand(seed);
	
	int max_par = 10; //maximum number of parameters of a function	
	
	//allocating memory
	double * fPar = (double *)malloc(max_par*sizeof(double));
		
	int N = 10000; //number of points
	
	//file with sampled data from a gaussian
	FILE * file;
	file = fopen("data/data_for_importance_sampling.txt", "r");
	
	//integration interval
	double inf = 0;
	double sup = 10;
	
	//variable to store samples from data
	double sample;
	double * samplePtr = &sample;
	
	
	printf("Crude monte carlo result with N=%d:\n%f\n", N, crude_monte_carlo(N, inf, sup, f, fPar));
	
	//Computing the integral with importance sampling
	double I = 0;
	for(int j =0; j< N; j++){
		fscanf(file, "%lf", samplePtr);
		I = I + g(sample);
	}
	I = sqrt(PI)/2*I/N; //from calculations
	
	printf("Importance sampling result with N=%d:\n%f\n", N, I);
	
	
	//freeing the memory
	free(fPar);
	fclose(file);
	
	return 0;	
}


//function that enters in the definition of the function to integrate
double g(double x){
	double out = x; //arbitrary choice
	return out;
}

//function to be integrated
double f(double x, double * fPar){
	double out = exp(-x*x)*g(x);
	return out;
}
