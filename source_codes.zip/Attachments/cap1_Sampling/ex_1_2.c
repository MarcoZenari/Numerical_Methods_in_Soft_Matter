#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "nmsm.h"  //module with my costum functions

int main(){
	int N = 10000; //number of point sampled
	
	//Initialization of the random generator
	int seed = 12102023;
	srand(seed); 
	
	//parameters of power law distribution
	double n = 2;
	double inf = 0;
	double sup = 2;
	
	FILE * file; //defining the pointer to the file
	
	file = fopen("data/data_power_sample_3.txt", "w"); //opening the file to save the data
	
	//header
	fprintf(file, "# n = %f \t inf = %f \t sup = %f \t n_samples = %d \n", n, inf, sup, N);
	
	for(int i=0; i<N; i++){
		//saving in the file the sample
		fprintf(file, "%f\n", power_sampler(n, inf, sup));
	}
	
	//closing the file
	fclose(file);


	return 0;
}
