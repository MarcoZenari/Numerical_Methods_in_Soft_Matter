#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14159265358979323846

/*
####################
PROTOTYPES
####################
*/

/* uniform
Sample a random number from a uniform distribution between 0 and 1;
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double uniform(); 

/* uniform_interval
Sample a random number from a uniform distribution between inf and sup;
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double uniform_interval(double inf, double sup);

/* power_sampler
Sample a random variable from the power law distribution p(x)=x^n with x€[inf, sup]
The distribution is normalized directly from the algorithm
The sampling is done by Inversion Method
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double power_sampler(double n, double inf, double sup);


/* box_muller
Sample two gaussian random variable from a normal distribution with loc=mu and sc=sigma
The sampling is done by coordinates transformation + inversion method
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double * box_muller(double mu, double sigma);


/* rejection_method_sampling
Sample from a distribution double f(double x, double *fPar) with rejection method using
double g(double x, double *gPar) as limiting function and the corresponding inverse cdf for sampling from g(x) with inversion method  double inv_F(double y, double * inv_FPar)
double c  is the costant used in the rejection method
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double rejection_method_sampling(double(*f)(double, double *), double(*g)(double, double *), double(*inv_F)(double, double*), double c, double *fPar, double *gPar, double *inv_FPar);


/*crude_monte_carlo
Crude monte carlo method to compute the integral of a function f.
!!! Needs to initialize the random generator before use:
	Ex: Initialization of the random generator of <stdlib.h>
		int seed = 11102023;
		srand(seed); 
*/
double crude_monte_carlo(int N, double inf, double sup, double(*f)(double, double *), double * fPar);

/*
####################
FUNCTIONS
####################
*/

double uniform(){
	//rand() samples an integer between 0 and RAND_MAX from random generato of stdlib
	double out = (double)rand()/(RAND_MAX+1.);
	return out;
}

double uniform_interval(double inf, double sup){
	//reparametrize the uniform sample U[0,1] in U[inf, sup]
	double out = inf + (sup - inf)*uniform();
	return out;
}

double power_sampler(double n, double inf, double sup){
	double r = uniform(); //sample r~U[0,1]
	double c = (n+1)/(pow(sup, n+1)-pow(inf, n+1)); //normalization factor
	double base = (r+c*pow(inf, n+1)/(n+1))*(n+1)/c; //base of the following power
	double out = pow(base, 1/(n+1)); // Espression obtained from inversion method
	return out;
}


double * box_muller(double mu, double sigma){
	double * x = (double *)malloc(2*sizeof(double)); //creating a pointer allocation memory
	double u1 = uniform(); //sampling a uniform rv
	double u2 = uniform(); //sampling a uniform rv
	//using box-muller transformations to obtain two normal gaussian rv
	x[0] = sqrt(-2*log(u1))*cos(2*PI*u2);
	x[1] = sqrt(-2*log(u1))*sin(2*PI*u2); 
	//reparametrize the rv to a N[mu, sigma^2]
	x[0] = mu + x[0]*sigma;
	x[1] = mu + x[1]*sigma;
	//returning the pointer
	return x;
}


double rejection_method_sampling(double(*f)(double, double *), double(*g)(double, double *), double(*inv_F)(double, double*), double c, double *fPar, double *gPar, double *inv_FPar){
	double out;	//for return
	double y1;	//extract variable for sampling from g with inverse method
	double y2;	//extract variable for rejection method
	double X; 	// variable sampled from g
	do{
		//sampling until I find an accepted sample
		y1 = uniform();
		y2 = uniform();
		X = inv_F(y1, inv_FPar);	//sampling from g with inverse of cdf
		out = X;
	}while(y2>=f(X, fPar)/(c*g(X, gPar))); 	//condition to reject the sample
	
	return out;	
}


double crude_monte_carlo(int N, double inf, double sup, double(*f)(double, double *), double * fPar){

	double out = 0; //output
	double x; //to store sampled data
	for(int i=0; i<N; i++){
		x = uniform_interval(inf, sup); //sampling uniform in [inf, sup]
		out = out + f(x, fPar); //summing the value of f a the sampled data
		}
	out = (sup-inf)*out/N; //averaging and returning the estimation of the integral
	return out;
}

