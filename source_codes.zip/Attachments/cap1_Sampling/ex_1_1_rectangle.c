#include <stdio.h>
#include <stdlib.h>

#include "nmsm.h" //my own module with costum functions


int main(){
	
	//Definition of the intevals [a,b], [c,d]
	double a = 0;
	double b = 4;
	double c = 2;
	double d = 3;
	
	double true_area = (d-c)*(b-a); //true area of the rectangle
	
	int N = 1000; //number of points generated
	
	double x = 0;
	double y = 0;
	
	//Initialization of the random generator
	int seed = 11102023;
	srand(seed); 
	
	//counter for hit and miss
	int count = 0;
	
	//Generation of uniform numbers in the rectangle and count hit and miss
	for(int i = 0; i < N; i++){
		x = uniform_interval(a, b);
		y = uniform_interval(c, d);
		//printf("%f \t %f \n", x, y);
		if ((x>=a && x<=b) && (y>=c && y<=d)){
			count++;
		}
	}
	
	//calculating the area
	double area = (double)count/N*(b-a)*(d-c);
	
	printf("The area of the rectangle by hit/miss is: %f \n", area);
	printf("Analytic value of area of rectangle is: %f \n", true_area);
	
	return 0;
}
