 #!/bin/bash 
 
code=ex_2_1_disk.c	#change the name of the c file to compile
module=nmsm.c

gcc $code $module -lm
./a.out

rm a.out
