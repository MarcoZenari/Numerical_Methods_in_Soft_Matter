// Standard libraries
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#define PI 3.14159265358979323846

// Source file
#include "random.h"
#include "definitions.h"
#include "utils.h"
#include "init.h"
#include "integrator.h"

int main(){
	//read input file
	read_input_file();
	//initialize random generator
	//srand(mySys.Seed);
	srand(time(NULL));
	
	//printing in std-output parameters of simulation
	printf("N:\t%d\tN_steps:\t%d\tT:\t%f\tgamma:%f\tK:%f\n", mySys.N_particles, mySys.N_steps, mySys.Temperature, mySys.gamma, mySys.K);
	
	
	//For on the number of realizations
	for(int n = 0; n<mySys.N_realizations; n++){
	
		//printing in std-output number of iterations
		printf("Iteration:\t%d\t/\t%d\n", n+1, mySys.N_realizations);
		
		//allocate memory to store the particles
		allocate();
		
		//initialize the system
		initialization();
		
		
		//creating file for distances
		char filename[200];			
		sprintf(filename, "output/harmonic_trap_N_%d_time_%d_dt_%f_Temperature_%f_gamma_%f_K_%f_realization_%d.txt", mySys.N_particles, mySys.N_steps, mySys.dt, mySys.Temperature, mySys.gamma, mySys.K, n);	
		//creating output file to store the data
		FILE * output_file = fopen(filename, "w");
		
		/*debugging
		for (int i = 0; i<mySys.N_particles; i++){
			printf("%d\t%f\t%f\t%f\t%f\n", i, particles[i].x, particles[i].y, particles[i].f_x, particles[i].f_y);
		}
		*/
		
		//saving initial positions
		for (int i=0; i<mySys.N_particles; i++){
			fprintf(output_file, "%f\t%d\t%f\t%f\n", 0., i, particles[i].x, particles[i].y);		
		}	
		
		printf("\t--> Evolving the system\n");
		
		for (int t = 1; t <= mySys.N_steps; t ++){
				
			second_order_integrator(); //for the overdamped case
			
			andersen_thermostat(); 
			//fprintf(output_file1, "%f\t%f\t%f\t%f\t%f\t%f\t%f\n", t*mySys.dt, avg_y(),avg_x(), avg_d_y(), avg_d_x(), var_y(avg_y()), var_x(avg_x()));
			
			for (int i=0; i<mySys.N_particles; i++){
				fprintf(output_file, "%f\t%d\t%f\t%f\n", t*mySys.dt, i, particles[i].x, particles[i].y);		
			}
		}
				
		//closing the file
		fclose(output_file);
		
		//deallocating memory	
		clean();
	}
	
	return 0;
}
