//for overdamped case
void first_order_integrator(){
	//updating positions
	for (int i = 0; i<mySys.N_particles; i++){
		
		//NB: Box mullers return an array of 2 gaussian samples
		double * x1 = box_muller(0., 1.);
		
		//updating positions
		particles[i].x = particles[i].x + forces(i, 0)/mySys.gamma/mySys.m*mySys.dt + mySys.strength*x1[0];
		particles[i].y = particles[i].y + forces(i, 1)/mySys.gamma/mySys.m*mySys.dt + mySys.strength*x1[1];
		
		//keeping the particle in the box
		particles[i].x = particles[i].x - floor(particles[i].x/mySys.L_x)*mySys.L_x;
		particles[i].y = particles[i].y - floor(particles[i].y/mySys.L_y)*mySys.L_y;	
	}
}



//for underdamped case
void second_order_integrator(){

	for (int i = 0; i<mySys.N_particles; i++){
		//sampling noise
		double * x1 = box_muller(0., 1.);
		double * x2 = box_muller(0., 1.);
		
		//saving old forces 
		particles[i].f_x_old = particles[i].f_x;
		particles[i].f_y_old = particles[i].f_y;
		
		//computing C
		double C_x = mySys.dt*mySys.dt/2.*(particles[i].f_x_old-mySys.gamma*particles[i].v_x)+sqrt((2.*mySys.Temperature*mySys.gamma)/(mySys.m))*sqrt(mySys.dt*mySys.dt*mySys.dt)*(0.5 * x1[0]+1./(2.*sqrt(3.))*x1[1]);
		
		double C_y = mySys.dt*mySys.dt/2.*(particles[i].f_y_old-mySys.gamma*particles[i].v_y)+sqrt((2.*mySys.Temperature*mySys.gamma)/(mySys.m))*sqrt(mySys.dt*mySys.dt*mySys.dt)*(0.5 * x2[0]+1./(2.*sqrt(3.))*x2[1]);
		
		//updating positions
		particles[i].x = particles[i].x + mySys.dt*particles[i].v_x + C_x;	
		particles[i].y = particles[i].y + mySys.dt*particles[i].v_y + C_y;
		
		//keeping the particle in the box
		particles[i].x = particles[i].x - floor(particles[i].x/mySys.L_x)*mySys.L_x;
		particles[i].y = particles[i].y - floor(particles[i].y/mySys.L_y)*mySys.L_y;
		
		
		//computing new forces
		particles[i].f_x = forces(i, 0);
		particles[i].f_y = forces(i, 1);
		
		//updating velocities
		particles[i].v_x = particles[i].v_x + mySys.dt/2.*(particles[i].f_x + particles[i].f_x_old) - mySys.dt*mySys.gamma*particles[i].v_x + sqrt((2.*mySys.Temperature*mySys.gamma)/(mySys.m))*sqrt(mySys.dt)*x1[0]-mySys.gamma*C_x;	
		particles[i].v_y = particles[i].v_y + mySys.dt/2.*(particles[i].f_y + particles[i].f_y_old) - mySys.dt*mySys.gamma*particles[i].v_y + sqrt((2.*mySys.Temperature*mySys.gamma)/(mySys.m))*sqrt(mySys.dt)*x2[0]-mySys.gamma*C_y;	
				
		free(x1);
		free(x2);
	}

}

