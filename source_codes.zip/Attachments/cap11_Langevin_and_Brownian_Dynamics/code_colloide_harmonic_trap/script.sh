#!/bin/bash

#compiling the code
make

# Create the input file
output_file="input.dat"

# Store the input parameters lists
T_list=("1.0") #("0.1" "0.2" "0.4" "0.6" "0.8" "1." "1.2" "1.4" "1.6" "1.8" "2.0")
gamma_list=("1.0") #("1.0" "10." "20." "30." "40." "50." "60." "70." "80." "90." "100.")
K_list=("0.1" "1.0" "2.0" "3." "4." "5." "6." "7." "8." "9." "10.")

# For loop on parameters
for T in "${T_list[@]}"; do

	for gamma in "${gamma_list[@]}"; do
	
		for K in "${K_list[@]}"; do

			#remove previous file if exists
			if [ -e "$output_file" ]; then
				rm "$output_file"
			fi
				
			#writing the input file
			
			echo "N_particles = 400" >> "$output_file"
			echo "N_steps = 10000" >> "$output_file"
			echo "dt = 0.01" >> "$output_file"
			echo "sigma = 1." >> "$output_file"
			echo "eps = 1." >> "$output_file"
			echo "Seed = 12152705" >> "$output_file"
			echo "Initialization = harmonic_trap" >> "$output_file"
			echo "N_realizations = 1" >> "$output_file"
			echo "Mass = 1." >> "$output_file"
			echo "L_x = 20" >> "$output_file"
			echo "L_y = 20" >> "$output_file"
			echo "delta_r = 3.0" >> "$output_file"
			echo "K = $K" >> "$output_file"
			echo "Temperature = $T" >> "$output_file"
			echo "gamma = $gamma" >> "$output_file"
			
			#running the code
			./executable.out
			
		done
		
	done
	
done

#cleaning
make clean 



