// Struct Particle
typedef struct {
	//position of the particle at time t
	double x;
	double y;
	double z;
		
	//position of the particle at time t
	double x0;
	double y0;
	double z0;
			
		
	//velocities of the particles at time t
	double v_x;
	double v_y;
	double v_z;
	
	//forces acting on particle at time t
	double f_x;
	double f_y;
	double f_z;
	
	//forces acting on particle at time t-1
	double f_x_old;
	double f_y_old;
	double f_z_old;
	
	//position of the particle at time t-1
	double x_old;
	double y_old;
	double z_old;
	
} Particle;


Particle * particles = NULL; //initializing to Null the pointer to the particles


// Struct system
typedef struct {
	int N_particles; //number of particles
	int N_steps; //number of steps of integration
	double dt; //duration of time step
	double L_x; //dimension of the system along x
	double L_y; //dimension of the system along y
	double L_z; //dimension of the system along z	
	double m; //mass of the particles
	double Temperature; //temperature of the system
	double gamma; //friction coefficient
	double sigma; //parameter of the Lennard-Jones model
	double eps; //parameter of the Lennard-Jones model
	int Seed;	//seed to intialize random generator	
	char Initialization[20];	//codeword to choose initialization of the system
	int N_realizations;  //Number of realizations of the system
	double strength; //strength of the Brownian noise
	double MSD; //Mean Square dipslacement of the system
} System;

System mySys;  //initializing the system



