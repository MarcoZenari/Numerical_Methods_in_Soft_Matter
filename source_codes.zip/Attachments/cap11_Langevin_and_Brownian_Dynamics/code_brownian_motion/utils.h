//Allocate the memory needed to store the particles
void allocate(){
	particles = (Particle*)malloc(mySys.N_particles*(sizeof(Particle)));
}

//Free the memory used to store the particles
void clean(){
	free(particles);
}


//print to std output the x,y,z positions of each particle (debugging porpouse)
void print_config(){
	for (int i = 0; i < mySys.N_particles; i++){
		printf("%d\t%f\t%f\t%f\t%f\t%f\t%f\n", i, particles[i].x, particles[i].y, particles[i].z, particles[i].v_x, particles[i].v_y, particles[i].v_z);			
	}

}

//function to shorten a string given in input
void shortenString(char *str) {
    // Iterate through the characters in the string
    for (int i = 0; str[i] != '\0'; i++) {
        // If a white space character is found, truncate the string
        if (isspace(str[i])) {
            str[i] = '\0';
            break;
        }
    }
}

//compute the forces acting on particle i along direction j
double forces(int i, int j){
	double out = 0.;	
	double * x = box_muller(0., 1.);
	if (j==0){
		out = -mySys.gamma*particles[i].v_x + mySys.strength/sqrt(mySys.dt*mySys.dt*mySys.dt)*x[0];
	}
	
	if (j==1){
		out = -mySys.gamma*particles[i].v_y + mySys.strength/sqrt(mySys.dt*mySys.dt*mySys.dt)*x[0];

	}
	
	if (j==2){
		out = -mySys.gamma*particles[i].v_z + mySys.strength/sqrt(mySys.dt*mySys.dt*mySys.dt)*x[0];
	}
		
	return out;
}

//Initialize the system based on the word code in input file
void initialization(){
	printf("\t--> Initializing the system\n");
	
	//computing the strength of the Brownian noise
	mySys.strength =  sqrt((2.*mySys.Temperature*mySys.dt)/(mySys.m*mySys.gamma));
	
	//Center initialization: initialize all the particles in the center of the box (used for ideal gas diffusion)
	if (strcmp(mySys.Initialization, "center")==0){
	
		//initializing positions
		for (int i = 0; i < mySys.N_particles; i++){
		
			//initializing the particles positions
			particles[i].x = mySys.L_x/2.;
			particles[i].y = mySys.L_y/2.;
			particles[i].z = mySys.L_z/2.;	
			
			//saving the initial positions of the particles
			particles[i].x0 = mySys.L_x/2.;
			particles[i].y0 = mySys.L_y/2.;
			particles[i].z0 = mySys.L_z/2.;		
				
		}
		
		
		//Initializing velocities
		for (int j = 0; j < mySys.N_particles; j ++){
			//NB: Box mullers return an array of 2 gaussian samples
			double * x1 = box_muller(0., sqrt(mySys.Temperature/mySys.m));
			double * x2 = box_muller(0., sqrt(mySys.Temperature/mySys.m));
			particles[j].v_x = x1[0] ;
			particles[j].v_y = x1[1];
			particles[j].v_z = x2[0];
			free(x1);
			free(x2);
		}
		
	}
	
	
	
	//Random initialization
	if (strcmp(mySys.Initialization, "random")==0){
		for (int i = 0; i < mySys.N_particles; i++){
			particles[i].x = uniform_intervall(0., mySys.L_x);
			particles[i].y = uniform_intervall(0., mySys.L_y);
			particles[i].z = uniform_intervall(0., mySys.L_z);			
		}
	}
	
	//Cubic lattice initialization
	if (strcmp(mySys.Initialization, "cubic_lattice")==0){
		int tmp = 0;
		int lattice_size =  ceil(cbrt(mySys.N_particles));
		double lattice_pace_x = mySys.L_x/(lattice_size+2.);
		double lattice_pace_y = mySys.L_y/(lattice_size+2.);
		double lattice_pace_z = mySys.L_z/(lattice_size+2.);
		 
		
		//Assigning particles on a cubic lattice
		
		for (int i = 1; i <= lattice_size+1; i++){
			for (int j = 1; j <=lattice_size+1; j++){
				for (int k = 1; k <= lattice_size+1; k++){
				
					//particle initialization
					particles[tmp].x = i*lattice_pace_x;
					particles[tmp].y = j*lattice_pace_y;
					particles[tmp].z = k*lattice_pace_z;
						
					tmp++;
					
					//checking if we have assigned all particles
					if(tmp == mySys.N_particles){
						break;
					}
				}
				if(tmp == mySys.N_particles){
						break;
				}
			}
			if(tmp == mySys.N_particles){
						break;
			}
		}
				
		//for debugging
		if (tmp!=(mySys.N_particles)){
			printf("Error in cubic_lattice initialization\n");
		}
				
	}
}


//Compute the mean squarte displacement of the pasticles
void compute_MSD(){
	double out = 0.;
	for (int i = 0; i<mySys.N_particles; i++){
		out = out + (particles[i].x-particles[i].x0)*(particles[i].x-particles[i].x0);
		out = out + (particles[i].y-particles[i].y0)*(particles[i].y-particles[i].y0);
		out = out + (particles[i].z-particles[i].z0)*(particles[i].z-particles[i].z0);
	}
	out = out/mySys.N_particles;
	mySys.MSD = out;
}
