#!/bin/bash

#compiling the code
make

# Create the input file
output_file="input.dat"

# Store the input parameters lists
r_list=("0.0" "0.2" "0.4" "0.6" "0.8" "1.0" "1.2" "1.4" "1.6" "1.8" "2.0")

# For loop on parameters
for r in "${r_list[@]}"; do

	
	#remove previous file if exists
	if [ -e "$output_file" ]; then
		rm "$output_file"
	fi
				
	#writing the input file
	
	echo "N_particles = 400" >> "$output_file"
	echo "N_steps = 10000" >> "$output_file"
	echo "dt = 0.01" >> "$output_file"
	echo "sigma = 1." >> "$output_file"
	echo "eps = 1." >> "$output_file"
	echo "Seed = 12152705" >> "$output_file"
	echo "Initialization = harmonic_trap" >> "$output_file"
	echo "N_realizations = 1" >> "$output_file"
	echo "Mass = 1." >> "$output_file"
	echo "L_x = 20" >> "$output_file"
	echo "L_y = 20" >> "$output_file"
	echo "delta_r = $r" >> "$output_file"
	echo "K = 1.0" >> "$output_file"
	echo "Temperature = 1.0" >> "$output_file"
	echo "gamma = 1.0" >> "$output_file"
	
	#running the code
	./executable.out

done

#cleaning
make clean 



