//Allocate the memory needed to store the particles
void allocate(){
	particles = (Particle*)malloc(mySys.N_particles*(sizeof(Particle)));
}

//Free the memory used to store the particles
void clean(){
	free(particles);
}


//print to std output the x,y,z positions of each particle (debugging porpouse)
void print_config(){
	for (int i = 0; i < mySys.N_particles; i++){
		printf("%d\t%f\t%f\n", i, particles[i].x, particles[i].y);			
	}

}

//function to shorten a string given in input
void shortenString(char *str) {
    // Iterate through the characters in the string
    for (int i = 0; str[i] != '\0'; i++) {
        // If a white space character is found, truncate the string
        if (isspace(str[i])) {
            str[i] = '\0';
            break;
        }
    }
}

//compute the forces acting on particle i along direction j
double forces(int i, int j){
	double out = 0.;

	double r0_x = mySys.L_x/2.-2.;
	double r0_y = mySys.L_y/2.;
	
	double r1_x = r0_x+4.;
	double r1_y = r0_y; 
			
	if (j==0){
		out = out -mySys.K*(particles[i].x-r0_x);
		out = out -mySys.K*(particles[i].x-r1_x);
	}
	
	if (j==1){
		out = out -mySys.K*(particles[i].y-r0_y);
		out = out -mySys.K*(particles[i].y-r1_y);
	}		
	return out;
}


//Initialize the system based on the word code in input file
void initialization(){
	printf("\t--> Initializing the system\n");
	
	//computing the strength of the Brownian noise
	mySys.strength =  sqrt((2.*mySys.Temperature*mySys.dt)/(mySys.m*mySys.gamma));
	
	//Center initialization: initialize all the particles in the center of the box (used for ideal gas diffusion)
	if (strcmp(mySys.Initialization, "harmonic_trap")==0){
	
		//initializing positions
		for (int i = 0; i < mySys.N_particles; i++){
			
			//initializing the particles positions
			particles[i].x = mySys.L_x/2. -2.0 + mySys.delta_r;
			particles[i].y = mySys.L_y/2.;	
			
			//saving the initial positions of the particles
			particles[i].x0 = mySys.L_x/2. -2.0 + mySys.delta_r;
			particles[i].y0 = mySys.L_y/2.;
		}
		
		//Initializing velocities
		for (int j = 0; j < mySys.N_particles; j ++){
			//NB: Box mullers return an array of 2 gaussian samples
			double * x1 = box_muller(0., sqrt(mySys.Temperature/mySys.m));
			particles[j].v_x = x1[0];
			particles[j].v_y = x1[1];
			free(x1);
		}
		
		//Initializing forces
		for (int i =0; i<mySys.N_particles; i++){
			particles[i].f_x = forces(i, 0);
			particles[i].f_y = forces(i, 1);
		}	
	}
}

// Andersen thermostat
void andersen_thermostat(){
	double omega  = 10.;
	double prob = mySys.dt*omega;
	for (int i = 0; i<mySys.N_particles; i++){
		if( uniform() < prob){
			double * x1 = box_muller(0., sqrt(mySys.Temperature/mySys.m));
			particles[i].v_x = x1[0] ;
			particles[i].v_y = x1[1];
		}
	}
}
