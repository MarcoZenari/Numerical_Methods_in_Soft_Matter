 #!/bin/bash 
 
code=ising_wolff.c
module=nmsm.c

gcc -o2 $code $module -lm -o es.out
./es.out

rm es.out
