//main libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "nmsm.h"	//module with costume functions


//function to randomly initialize the system
void initialization(int * state, int N);

//function to compute the energy contribution of state[i] and state[j]
void energy_contribution(double * energy_pairs, int * state, int i, int j, int L, int N, double J);

//Function that return 1 if site i and site j are nn or 0 otherwise
//Implements also Periodic Boundary Conditions
int nn_verify(int i, int j, int L);

//Function to compute the total energy
void tot_energy(double * energy, double * energy_pairs, int N);

//Function to compute the magnetization per Spin
void tot_magnetization(double * magnetization, int * state, int N);

//Function tha search for the nn of a spin j; Implements also periodic boundary conditions
void nearest_neighbours(int j, int * nn, int L);

//Function to update the state with Glauber-proposed move and Metropolis acceptance matrix
void update_glauber_metropolis(int * state, int * nn, int L, int N, double * energy_pairs, double beta, double J, double *energy, double *magnetization);

//Update using Wolff Cluster algorithm
void update_wolff(int * state, int * cluster, int * cluster_size, int * nn, double * p_add, int L, int N, double *energy, double *magnetization, double J);

//Swap of configurations between Markov Chains
void swap(int ** MMC, double ** energy,double **energy_pairs, double **magnetization, double beta[], int Nchains, FILE * file);


int main(){

	//initialization of random generator
	int seed = 2129;
	srand(seed);
		
	//Parameters of the simulations
	int L=20; //system length
	int Nchains =6; //number of chains
	double beta[6]={0.41, 0.42, 0.43, 0.44, 0.45, 0.46};//possible temperatures (J=1, Kb=1)
	int d = 2;	//spatial dimension
	int N = L*L;	//total number of spins
	double J = 1.; 	//interaction costant
	int max_time = 30000; //duration of simulation
	int swap_time = 10; //block of times in between swaps
	
	
	//Pointers for the simulation
	
	//pointer list to pointers for each chain
	int**MMC = (int **)malloc(Nchains * sizeof(int*));
	double**energy_pairs = (double**)malloc(Nchains*sizeof(double*));
	double**energy = (double**)malloc(Nchains*sizeof(double*));
	double**magnetization = (double**)malloc(Nchains*sizeof(double*));
	
	//defining the list of pointers to the energy pairs contributions and states
	
	for (int k=0; k< Nchains; k++){
		*(MMC+k)= (int *)malloc(N*sizeof(int));
		*(energy_pairs+k)= (double *)malloc(N*(N-1)/2*sizeof(double));
		*(energy+k) = (double *)malloc(1*sizeof(double));
		*(magnetization+k) = (double *)malloc(1*sizeof(double));
	}	
	
	//pointer to the vector of the neigbours of glauber choice
	int * nn = (int  *)malloc(4*sizeof(int));
	
	/*
	//MMC with Wolff to be implemented
	//pointer to the cluster array
	int * cluster = (int *)malloc(N*sizeof(int));
	
	//pointer to the cluster size
	int * cluster_size = (int *)malloc(1*sizeof(int));

	//probability of adding a spin to the cluster
	double p_add = 1- exp(-2*beta*J);
	*/
	
	
	
	//file where to save data
		
	char filename[150];
	
	sprintf(filename, "data_MMC/Ising_2D_MMC_glauber_SWAP_N%d_L%d_Nchains%dtime%d.txt", N, L, Nchains, max_time);
	
	
	//Creating file to save the data
	FILE * file = fopen(filename, "w");

	
	//printing header
	fprintf(file, "#time\t");
	for (int k=0; k< Nchains; k++){
		fprintf(file, "en_beta=%f\tmag_beta=%f\t", beta[k], beta[k]);
	}
	fprintf(file, "swap\n");	
	
	
	//INITIALIZATION AND PRINTING FIRST LINE

	//printing first line
	fprintf(file, "0\t");
			
	//For each chain
	for (int k=0; k<Nchains; k++){
		//initialize the system
		initialization(*(MMC+k), N);
		//compute initial energy pairs
		for(int i=0; i<N; i++){
			for(int j=i+1; j<N; j++){
				energy_contribution(*(energy_pairs+k),*(MMC+k),i,j,L,N,J);
			}
		}
		//compute initial totale enrgy
		tot_energy(*(energy+k), *(energy_pairs+k), N);
		//compute total initial magnetization
		tot_magnetization(*(magnetization+k), *(MMC+k), N);
		
		fprintf(file,"%f\t%f\t",**(energy+k), **(magnetization+k));
	}
	fprintf(file, "NO\n"); 
	
	
	//TIME EVOLUTION
	
	for(int t = 1; t < max_time; t++){
		fprintf(file,"%d\t", t);
		
		//Glauber-Metropolis algorithm
		for(int k =0; k<Nchains; k++){
		
			//GLAUBER
			for(int count = 0; count <N; count++){
				//update the system
				update_glauber_metropolis(*(MMC+k),nn,L,N,*(energy_pairs+k),beta[k],J,*(energy+k), *(magnetization+k));
			}
			//
			
			/*WOLF
			
			//pointer to the cluster array
			int * cluster = (int *)malloc(N*sizeof(int));
			
			//pointer to the cluster size
			int * cluster_size = (int *)malloc(1*sizeof(int));

			//probability of adding a spin to the cluster
			double * p_add = (double*)malloc(sizeof(double*));
			*p_add =  1- exp(-2*beta[k]*J);
			//Update using Wolff Cluster algorithm
			update_wolff( *(MMC+k), cluster, cluster_size, nn, p_add, L, N, *(energy+k),*(magnetization+k), J);
			
			
			free(cluster);
			free(cluster_size);
			free(p_add);
			/*compute changed energy pairs
			for(int i=0; i<((*cluster_size)-1); i++){
				nearest_neighbours(*(cluster+i), nn, L);
				for(int j=0; j<4; j++){
				energy_contribution(energy_pairs,state,*(cluster+i),*(nn+j),L,N,J);
			}
			*/

			//print the data
			fprintf(file, "%e\t%e\t",**(energy+k), **(magnetization+k));
		}
		//fprintf(file, "NO\n");
		//
		if(t%swap_time==0){
			swap(MMC, energy, energy_pairs, magnetization, beta, Nchains, file);
		
		}else{
			fprintf(file, "NO\n");
		}	
		//
	}
	
	

	//memory deallocation
	
	for (int k =0; k<Nchains; k++){
		free(*(MMC+k));
		free(*(energy_pairs+k));
		free(*(energy+k));
		free(*(magnetization+k));
	}
	
	//freeing the memory
	free(nn);
	
	/* Wolff MMC to be implemented
	free(cluster);
	free(cluster_size);
	*/
	
	//closing the file
	fclose(file);
		
	return(0);	
}



//function to randomly initialize the system
void initialization(int * state, int N){
	for(int i = 0; i < N; i++){
		if(uniform()<0.5){
			*(state + i) = -1;
		}else{
			*(state + i) = +1;
		}
	}
}

//function to compute the energy contribution of state[i] and state[j]
void energy_contribution(double * energy_pairs, int * state, int i, int j, int L, int N, double J){
	if(j<i){
		j = i + j;
		i = j - i;
		j = j - i;
	}
	int index = i*(N-1)-i*(i-1)/2+j-(i+1);
	
	if(nn_verify(i, j, L)){
		*(energy_pairs+i*(N-1)-i*(i-1)/2+j-(i+1)) = -J*(*(state+i)* *(state+j));
	}else{
		*(energy_pairs+i*(N-1)-i*(i-1)/2+j-(i+1)) = 0;
	}
}


//Function that return 1 if site i and site j are nn or 0 otherwise
//Implements also Periodic Boundary Conditions
int nn_verify(int i, int j, int L){
	int out = 0;
	
	int x_i = i/L;
	int y_i = i%L;
	
	int x_j = j/L;
	int y_j = j%L;
	
	int deltaX = abs(x_i-x_j);
	int deltaY = abs(y_i-y_j);
	
	if(((deltaX == 0) && (deltaY == 1))||((deltaX == 1) && (deltaY == 0))){ //nn
		out = 1;
	}else if (((deltaX == L-1) && (deltaY == 0))||( (deltaX==0) && (deltaY==L-1))){ //PBC
		out = 1;
	}
	return out;
}	

//Function to compute the total energy
void tot_energy(double * energy, double * energy_pairs, int N){
	double out = 0;
	for (int i = 0; i<N*(N-1)/2; i++){
		out = out + *(energy_pairs+i);
	}
	*energy = out;
}

//Function to compute the magnetization per Spin
void tot_magnetization(double * magnetization, int * state, int N){
	double out = 0;
	for(int i = 0; i<N; i++){
		out = out + *(state+i);
	}
	*magnetization = out;
}

//Function to update the state with Glauber-proposed move and Metropolis acceptance matrix
void update_glauber_metropolis(int * state, int * nn, int L, int N, double * energy_pairs, double beta, double J, double *energy, double *magnetization){
	int j = random_integer(0, N-1); //Glauber proposed spin
	nearest_neighbours(j, nn, L); //Computing nn of proposed spin
	
	//computing the energy before the move
	double E0 = 0;
	int inf = 0;
	int sup = 0;
	
	for(int i = 0; i <4; i++){
		if(j<*(nn+i)){
			inf = j;
			sup = *(nn+i);
		}else{
			inf = *(nn+i);
			sup = j;
		}
			
		E0 = E0 + *(energy_pairs+inf*(N-1)-inf*(inf-1)/2+sup-(inf+1));
	}
	
	//move
	*(state + j) = *(state+j)*(-1);
	
	
	//computing the energy after the move
	double E1 = 0;
	inf = 0;
	sup = 0;
	
	for(int i = 0; i <4; i++){
		
		if(j< *(nn+i)){
			inf = j;
			sup = *(nn+i);
		}else{
			inf = *(nn+i);
			sup = j;
		}
		
		energy_contribution(energy_pairs, state, inf, sup, L, N, J);	
		E1 = E1 + *(energy_pairs+inf*(N-1)-inf*(inf-1)/2+sup-(inf+1));
	}
	
	
	//accepting or reversing the move as Metropolis
	double r = 0;
	if(E1>E0){
		r = uniform();
		//printf("%f\t%f\t%f\t%f\n", r, E0, E1, exp(-beta*(E1-E0))); //debugging
		
		if(r > exp(-beta*(E1-E0))){
			//invert the move (reject the move)
			*(state + j) = *(state+j)*(-1);
			for(int i = 0; i <4; i++){
				energy_contribution(energy_pairs, state, j, *(nn+i), L, N, J);
			}
		}else{//otherwise keep the move 
			//adjourn energy and magnetization
			*energy = *energy +(E1-E0);  //adjourn total energy
			*magnetization = *magnetization +2* *(state+j); //adjourn total magnetization
		}
		
	}else{//otherwise keep the move 
			//adjourn energy and magnetization
			*energy = *energy +(E1-E0);  //adjourn total energy
			*magnetization = *magnetization +2* *(state+j); //adjourn total magnetization
	}
	//otherwise keep the move 
}


//Update using Wolff Cluster algorithm
void update_wolff(int * state, int * cluster, int * cluster_size, int * nn, double * p_add, int L, int N, double *energy, double *magnetization, double J){
	
	int seed_wolff = random_integer(0, N-1); //sampling the seed
	double r = 0; //used to draw probabilities
	int count = 0;  //used to count the cluster elements
	int position = 0; //to keep track of the position on the cluster array
	*(cluster + position) = seed_wolff;  //adding the first element of the cluster
	
	int present=0; //variable to check if a spin is already in the cluster
	int kink = 0; //to count the change in energy
	
	//Computing the cluster
	do{
		nearest_neighbours(*(cluster+position) , nn, L);	
		for(int i=0; i<4; i++){
		
			if(*(state+*(cluster+position))* *(state+*(nn+i))>0){
				
				for(int k=0; k<=count; k++){
					if(*(nn+i)==*(cluster+k)){
						present = 1;
					}
				}
				
				if(present==0){ 
				
					r = uniform();
					
					if(r<*p_add){
						count = count +1;
						*(cluster + count) = *(nn+i);
					}					
				}
					
				present=0;	
			}	
		}
		
		position=position+1;
		//printf("%d\t%d\n", position, count);
	}while(position<=count);
	
	//Adjourning the state of the cluster
	for (int k=0; k<= count; k++){
		*(state + *(cluster+k)) = *(state + *(cluster+k))*(-1); //flip the spin	
	}
	
	
	//Computing the kink to adjourn the energy
	present = 0;
	for (int k=0; k<=count; k++){
		
		nearest_neighbours(*(cluster+k), nn, L);
	
		for (int i=0; i<4; i++){
			for (int k2=0; k2<=count; k2++){
				if(*(nn+i)==*(cluster+k2)){
					present = 1;
				}
			}
			if(present == 0){
				kink = kink + (*(state+*(cluster+k)))* (*(state+*(nn+i)));
			}
			present = 0;		
		}
			
	}	
	
	*cluster_size = count +1; //adjourning the cluster size
	
	//Adjourning energy and magnetization
	*energy=*energy-2*J*kink;
	*magnetization=*magnetization+2*(count+1)* *(state+seed_wolff);
	
}


//Function tha search for the nn of a spin j; Implements also periodic boundary conditions
void nearest_neighbours(int j, int * nn, int L){
	//position on the lattice
	int x_j = j/L;
	int y_j = j%L;
	
	//updating the vector of nearest neighbours
	*(nn+0) = j -L;
	*(nn+1) = j -1;
	*(nn+2) = j +1;
	*(nn+3) = j +L;
	
	//Implementic periodic boundary conditions
	if(x_j == 0){
		*(nn+0) = L*L-L+j;
	}
	if(x_j == L-1){
		*(nn+3) = j+L-L*L;	
	}
	if(y_j == 0){
		*(nn+1) = j+L-1;
	}
	if(y_j == L-1){
		*(nn+2) = j - L + 1;
	}
}

//Function that swap the configurations of two markov chains
void swap(int ** MMC, double ** energy, double **energy_pairs, double **magnetization, double beta[], int Nchains, FILE * file){
	//randomnly sampling the configurations to swap
	int k1=random_integer(0, Nchains-1);
	int k2;
	if (k1==0){
		k2 = k1+1;
	} else if(k1==Nchains-1){
		k2= k1 -1;
	} else{
		double r = uniform();
		if(r>=0.5){
			k2=k1+1;
		}else{
			k2=k1-1;
		}
	}
	
	//computing the metropolis factor
	double P = exp((beta[k2]-beta[k1])*(**(energy+k2)-**(energy+k1)));
	
	//swapping memory adressess
	if(P>1){
		int* PtrMMC = *(MMC+k2);
		double *PtrEnergy = *(energy+k2);
		double *PtrEnergyPairs = *(energy_pairs+k2);
		double *PtrMagnetization = *(magnetization+k2);
		*(MMC+k2) = *(MMC+k1);
		*(MMC+k1) = PtrMMC;
		*(energy+k2) = *(energy+k1);
		*(energy+k1) = PtrEnergy;
		*(energy_pairs+k2) = *(energy_pairs+k1);
		*(energy_pairs+k1) = PtrEnergyPairs;
		*(magnetization+k2) = *(magnetization+k1);
		*(magnetization+k1) = PtrMagnetization;
		fprintf(file, "%d<->%d\n", k1, k2);
		
	} else if (uniform()<P){
		int* PtrMMC = *(MMC+k2);
		double *PtrEnergy = *(energy+k2);
		double *PtrEnergyPairs = *(energy_pairs+k2);
		double *PtrMagnetization = *(magnetization+k2);
		*(MMC+k2) = *(MMC+k1);
		*(MMC+k1) = PtrMMC;
		*(energy+k2) = *(energy+k1);
		*(energy+k1) = PtrEnergy;
		*(energy_pairs+k2) = *(energy_pairs+k1);
		*(energy_pairs+k1) = PtrEnergyPairs;
		*(magnetization+k2) = *(magnetization+k1);
		*(magnetization+k1) = PtrMagnetization;
		fprintf(file, "%d<->%d\n", k1, k2);			
	} else{
		fprintf(file, "NOT ACCEPTED\n");
	}	
}
