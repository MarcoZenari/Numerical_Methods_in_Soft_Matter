//main libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "nmsm.h"	//module with costume functions


//function to randomly initialize the system
void initialization(int * state, int N);

//function to compute the energy contribution of state[i] and state[j]
void energy_contribution(double * energy_pairs, int * state, int i, int j, int L, int N, double J);

//Function that return 1 if site i and site j are nn or 0 otherwise
//Implements also Periodic Boundary Conditions
int nn_verify(int i, int j, int L);

//Function to compute the total energy
void tot_energy(double * energy, double * energy_pairs, int N);

//Function to compute the total magnetization 
void tot_magnetization(double * magnetization, int * state, int N);

//Function tha search for the nn of a spin j; Implements also periodic boundary conditions
void nearest_neighbours(int j, int * nn, int L);

//Function to update the state with Glauber-proposed move and Metropolis acceptance matrix
//update also energy of the system and magnetization
void update_glauber_metropolis(int * state, int * nn, int L, int N, double * energy_pairs, double beta, double J, double * energy, double * magnetization);


int main(){

	//initialization of random generator
	int seed = 111123;
	srand(seed);
		
	//Beta_critcal_theoretical = 0.44068679350977147
	
	//Parameters of the simulations
	int L_value[4]={10, 20, 30, 40};	//system length
	double beta_value[40]={0.412, 0.413, 0.414, 0.415, 0.416, 0.417, 0.418, 0.419, 0.420, 0.421, 0.422, 0.423, 0.424, 0.425, 0.426, 0.427, 0.428, 0.429, 0.430, 0.431, 0.432, 0.433, 0.434, 0.435, 0.436, 0.437, 0.437, 0.438, 0.439, 0.440, 0.441, 0.442, 0.443, 0.444, 0.445, 0.446, 0.447, 0.448, 0.449, 0.450}; //possible temperatures (J=1, Kb=1)
	double beta=0;
	int L=0;
	int d = 2;	//spatial dimension
	int N = 0;	//total number of spins
	double J = 1.; 	//interaction costant
	int max_time = 500000; //duration of simulation
	
		
	for(int idx_beta=0; idx_beta<40; idx_beta++){
		for(int idx_L=0; idx_L<4; idx_L++){	
		
		
			//value for this simulation
			beta = beta_value[idx_beta];
			L = L_value[idx_L];
			
			
			printf("beta=%f\tL=%d\n", beta, L);
			
			N=L*L; //number of spins
			
			
			char filename[200];
			
			sprintf(filename, "data/Ising_2D_glauber_metropolis_N%d_L%d_beta%ftime%d.txt", N, L, beta, max_time);			
			
			//Creating file to save the data
			FILE * file = fopen(filename, "w");
		
			
			//printing header
			//fprintf(file, "#N=%d\tL=%d\tbeta=%f\ttime=%d\n", N, L, beta, max_time);
			
			
			//Pointers for the simulations
	
			//defining the pointer to the state of the system and allocating memory
			int * state = (int *)malloc(N*sizeof(int));
	
			//defining the pointer to the energy pairs contributions
			double * energy_pairs = (double *)malloc(N*(N-1)/2*sizeof(double));

			//defining the pointer to the energy of the system
			double * energy = (double *)malloc(1*sizeof(double));

			//pointer to save the magnetization
			double * magnetization = (double *)malloc(1*sizeof(double));

			//pointer to the vector of the neigbours of glauber choice
			int * nn = (int  *)malloc(4*sizeof(int));
			
			
			//initialize the system
			initialization(state, N);
			
			//compute initial energy pairs
			for(int i=0; i<N; i++){
				for(int j=i+1; j<N; j++){
					energy_contribution(energy_pairs, state, i, j, L, N, J);
				}
			}
			
			//compute total initial energy
			tot_energy(energy, energy_pairs, N);
			
			//compute total initial magnetization
			tot_magnetization(magnetization, state, N);
			
			fprintf(file, "0\t%e\t%e\n", *energy, *magnetization);
			
			for(int t = 1; t < max_time; t++){	
				for(int count = 0; count <N; count++){
					//update the system
					update_glauber_metropolis(state,nn,L,N,energy_pairs,beta,J, energy, magnetization);
				}

				//print the data
				fprintf(file, "%d\t%e\t%e\n",t, *energy, *magnetization);
			}
			
		
			
			//freeing the memory
			free(state);
			free(energy_pairs);	
			free(energy);
			free(magnetization);
			free(nn);
			
			//closing the file
			fclose(file);
		}
	}
	
	return(0);	
}



//function to randomly initialize the system
void initialization(int * state, int N){
	for(int i = 0; i < N; i++){
		if(uniform()<0.5){
			*(state + i) = -1;
		}else{
			*(state + i) = +1;
		}
	}
}


//function to compute the energy contribution of state[i] and state[j]
void energy_contribution(double * energy_pairs, int * state, int i, int j, int L, int N, double J){
	if(j<i){
		j = i + j;
		i = j - i;
		j = j - i;
	}
	int index = i*(N-1)-i*(i-1)/2+j-(i+1);  //map [i,j] in to an index on the vector energy_pairs [0, N*(n-1)/2-1]
	
	if(nn_verify(i, j, L)){ //if nn there is an energy contribution
		*(energy_pairs+index) = -J*(*(state+i)* *(state+j));
	}else{ //if not nn no energy contribution
		*(energy_pairs+index) = 0;
	}
}


//Function that return 1 if site i and site j are nn or 0 otherwise
//Implements also Periodic Boundary Conditions
int nn_verify(int i, int j, int L){
	int out = 0;
	
	int x_i = i/L;
	int y_i = i%L;
	
	int x_j = j/L;
	int y_j = j%L;
	
	int deltaX = abs(x_i-x_j);
	int deltaY = abs(y_i-y_j);
	
	if(((deltaX == 0) && (deltaY == 1))||((deltaX == 1) && (deltaY == 0))){ //nn
		out = 1;
	}else if (((deltaX == L-1) && (deltaY == 0))||( (deltaX==0) && (deltaY==L-1))){ //PBC
		out = 1;
	}
	return out;
}	


//Function to compute the total energy
void tot_energy(double * energy, double * energy_pairs, int N){
	double out = 0;
	for (int i = 0; i<N*(N-1)/2; i++){
		out = out + *(energy_pairs+i);
	}
	*energy = out;
}

//Function to compute the magnetization per Spin
void tot_magnetization(double * magnetization, int * state, int N){
	double out = 0;
	for(int i = 0; i<N; i++){
		out = out + *(state+i);
	}
	*magnetization = out;
}

//Function to update the state with Glauber-proposed move and Metropolis acceptance matrix
void update_glauber_metropolis(int * state, int * nn, int L, int N, double * energy_pairs, double beta, double J, double *energy, double *magnetization){
	int j = random_integer(0, N-1); //Glauber proposed spin
	nearest_neighbours(j, nn, L); //Computing nn of proposed spin
	
	//computing the energy before the move
	double E0 = 0;
	int inf = 0;
	int sup = 0;
	
	for(int i = 0; i <4; i++){
		if(j<*(nn+i)){
			inf = j;
			sup = *(nn+i);
		}else{
			inf = *(nn+i);
			sup = j;
		}
			
		E0 = E0 + *(energy_pairs+inf*(N-1)-inf*(inf-1)/2+sup-(inf+1));
	}
	
	//move
	*(state + j) = *(state+j)*(-1);
	
	
	//computing the energy after the move
	double E1 = 0;
	inf = 0;
	sup = 0;
	
	for(int i = 0; i <4; i++){
		
		if(j< *(nn+i)){
			inf = j;
			sup = *(nn+i);
		}else{
			inf = *(nn+i);
			sup = j;
		}
		
		energy_contribution(energy_pairs, state, inf, sup, L, N, J);	
		E1 = E1 + *(energy_pairs+inf*(N-1)-inf*(inf-1)/2+sup-(inf+1));
	}
	
	
	//accepting or reversing the move as Metropolis
	double r = 0;
	if(E1>E0){
		r = uniform();
		//printf("%f\t%f\t%f\t%f\n", r, E0, E1, exp(-beta*(E1-E0))); //debugging
		
		if(r > exp(-beta*(E1-E0))){
			//invert the move (reject the move)
			*(state + j) = *(state+j)*(-1);
			for(int i = 0; i <4; i++){
				energy_contribution(energy_pairs, state, j, *(nn+i), L, N, J);
			}
		}else{//otherwise keep the move 
			//adjourn energy and magnetization
			*energy = *energy +(E1-E0);  //adjourn total energy
			*magnetization = *magnetization +2* *(state+j); //adjourn total magnetization
		}
		
	}else{//otherwise keep the move 
			//adjourn energy and magnetization
			*energy = *energy +(E1-E0);  //adjourn total energy
			*magnetization = *magnetization +2* *(state+j); //adjourn total magnetization
	}
	//otherwise keep the move 
}




//Function tha search for the nn of a spin j; Implements also periodic boundary conditions
void nearest_neighbours(int j, int * nn, int L){
	//position on the lattice
	int x_j = j/L;
	int y_j = j%L;
	
	//updating the vector of nearest neighbours
	*(nn+0) = j -L;
	*(nn+1) = j -1;
	*(nn+2) = j +1;
	*(nn+3) = j +L;
	
	//Implementic periodic boundary conditions
	if(x_j == 0){
		*(nn+0) = L*L-L+j;
	}
	if(x_j == L-1){
		*(nn+3) = j+L-L*L;	
	}
	if(y_j == 0){
		*(nn+1) = j+L-1;
	}
	if(y_j == L-1){
		*(nn+2) = j - L + 1;
	}
}
