//main libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "nmsm.h"	//module with costume functions


//function to randomly initialize the system
void initialization(int * state, int N);

//function to compute the energy contribution of state[i] and state[j]
void energy_contribution(double * energy_pairs, int * state, int i, int j, int L, int N, double J);

//Function that return 1 if site i and site j are nn or 0 otherwise
//Implements also Periodic Boundary Conditions
int nn_verify(int i, int j, int L);

//Function to compute the total energy
void tot_energy(double * energy, double * energy_pairs, int N);

//Function to compute the total magnetization 
void tot_magnetization(double * magnetization, int * state, int N);

//Function tha search for the nn of a spin j; Implements also periodic boundary conditions
void nearest_neighbours(int j, int * nn, int L);

//Function to update the state with Glauber-proposed move and Metropolis acceptance matrix
//update also energy of the system and magnetization
void update_glauber_metropolis(int * state, int * nn, int L, int N, double * energy_pairs, double beta, double J, double * energy, double * magnetization);

//Update using Wolff Cluster algorithm
void update_wolff(int * state, int * cluster, int * cluster_size, int * nn, double * p_add, int L, int N, double *energy, double *magnetization, double J);



int main(){

	//initialization of random generator
	int seed = 55323;
	srand(seed);
		
	//Beta_critcal_theoretical = 0.44068679350977147
	
	//Parameters of the simulations
	int L_value[1]={30};	//system length
	double beta_value[21]={0.441, 0.442, 0.443, 0.444, 0.445, 0.4412, 0.4414, 0.4416, 0.4418, 0.4422, 0.4424, 0.4426, 0.4428, 0.4432, 0.4434, 0.4436, 0.4438, 0.4442, 0.4444, 0.4446, 0.4448}; //critical temperatures (J=1, Kb=1)
	
	double beta=0;
	int L=0;
	int d = 2;	//spatial dimension
	int N = 0;	//total number of spins
	double J = 1.; 	//interaction costant
	int max_time = 10000; //duration of simulation
	
		
	for(int idx_beta=0; idx_beta<21; idx_beta++){
		for(int idx_L=0; idx_L<1; idx_L++){	
		
		
			//value for this simulation
			beta = beta_value[idx_L];
			L = L_value[idx_L];
			
			
			printf("beta=%f\tL=%d\n", beta, L);
			
			N=L*L; //number of spins
			
			
			char filename[200];
			
			sprintf(filename, "data_es_12/Ising_2D_wolff_N%d_L%d_beta%ftime%d.txt", N, L, beta, max_time);			
			
			//Creating file to save the data
			FILE * file = fopen(filename, "w");
		
			
			//Pointers for the simulations
	
			//defining the pointer to the state of the system and allocating memory
			int * state = (int *)malloc(N*sizeof(int));
	
			//defining the pointer to the energy pairs contributions
			double * energy_pairs = (double *)malloc(N*(N-1)/2*sizeof(double));

			//defining the pointer to the energy of the system
			double * energy = (double *)malloc(1*sizeof(double));

			//pointer to save the magnetization
			double * magnetization = (double *)malloc(1*sizeof(double));		
			
			//probability of adding a spin to the cluster
			double * p_add = (double *)malloc(1*sizeof(double));
			*p_add = 1- exp(-2*beta*J);
			
			//initialize the system
			initialization(state, N);
			
			//compute initial energy pairs
			for(int i=0; i<N; i++){
				for(int j=i+1; j<N; j++){
					energy_contribution(energy_pairs, state, i, j, L, N, J);
				}
			}
			
			//compute total initial energy
			tot_energy(energy, energy_pairs, N);
			
			//compute total initial magnetization
			tot_magnetization(magnetization, state, N);
			
			fprintf(file, "0\t%e\t%e\tNaN\n", *energy, *magnetization);
			
			for(int t = 1; t < max_time; t++){
			
				
				//pointer to the cluster array
				int * cluster = (int *)malloc(N*sizeof(int));
				
				//pointer to the vector of the neigbours of glauber choice
				int * nn = (int  *)malloc(4*sizeof(int));
				
				//pointer to the cluster size
				int * cluster_size = (int *)malloc(1*sizeof(int));
			
				//Update using wolff algorithm, updates also energy and magnetization			
				update_wolff(state, cluster, cluster_size, nn, p_add, L, N, energy, magnetization, J);
				//print the data
				fprintf(file, "%d\t%e\t%e\t%d\n",t, *energy, *magnetization, *cluster_size);
				//freeing the memory
				free(cluster);
				free(nn);
				free(cluster_size);
			}
			
			//freeing the memory
			free(state);
			free(energy_pairs);	
			free(energy);
			free(magnetization);
			free(p_add);
			
			
			//closing the file
			fclose(file);
		}
	}
	
	return(0);	
}



//function to randomly initialize the system
void initialization(int * state, int N){
	for(int i = 0; i < N; i++){
		if(uniform()<0.5){
			*(state + i) = -1;
		}else{
			*(state + i) = +1;
		}
	}
}


//function to compute the energy contribution of state[i] and state[j]
void energy_contribution(double * energy_pairs, int * state, int i, int j, int L, int N, double J){
	if(j<i){
		j = i + j;
		i = j - i;
		j = j - i;
	}
	int index = i*(N-1)-i*(i-1)/2+j-(i+1);  //map [i,j] in to an index on the vector energy_pairs [0, N*(n-1)/2-1]
	
	if(nn_verify(i, j, L)){ //if nn there is an energy contribution
		*(energy_pairs+index) = -J*(*(state+i)* *(state+j));
	}else{ //if not nn no energy contribution
		*(energy_pairs+index) = 0;
	}
}


//Function that return 1 if site i and site j are nn or 0 otherwise
//Implements also Periodic Boundary Conditions
int nn_verify(int i, int j, int L){
	int out = 0;
	
	int x_i = i/L;
	int y_i = i%L;
	
	int x_j = j/L;
	int y_j = j%L;
	
	int deltaX = abs(x_i-x_j);
	int deltaY = abs(y_i-y_j);
	
	if(((deltaX == 0) && (deltaY == 1))||((deltaX == 1) && (deltaY == 0))){ //nn
		out = 1;
	}else if (((deltaX == L-1) && (deltaY == 0))||( (deltaX==0) && (deltaY==L-1))){ //PBC
		out = 1;
	}
	return out;
}	


//Function to compute the total energy
void tot_energy(double * energy, double * energy_pairs, int N){
	double out = 0;
	for (int i = 0; i<N*(N-1)/2; i++){
		out = out + *(energy_pairs+i);
	}
	*energy = out;
}

//Function to compute the magnetization per Spin
void tot_magnetization(double * magnetization, int * state, int N){
	double out = 0;
	for(int i = 0; i<N; i++){
		out = out + *(state+i);
	}
	*magnetization = out;
}

//Function to update the state with Glauber-proposed move and Metropolis acceptance matrix
void update_glauber_metropolis(int * state, int * nn, int L, int N, double * energy_pairs, double beta, double J, double *energy, double *magnetization){
	int j = random_integer(0, N-1); //Glauber proposed spin
	nearest_neighbours(j, nn, L); //Computing nn of proposed spin
	
	//computing the energy before the move
	double E0 = 0;
	int inf = 0;
	int sup = 0;
	
	for(int i = 0; i <4; i++){
		if(j<*(nn+i)){
			inf = j;
			sup = *(nn+i);
		}else{
			inf = *(nn+i);
			sup = j;
		}
			
		E0 = E0 + *(energy_pairs+inf*(N-1)-inf*(inf-1)/2+sup-(inf+1));
	}
	
	//move
	*(state + j) = *(state+j)*(-1);
	
	
	//computing the energy after the move
	double E1 = 0;
	inf = 0;
	sup = 0;
	
	for(int i = 0; i <4; i++){
		
		if(j< *(nn+i)){
			inf = j;
			sup = *(nn+i);
		}else{
			inf = *(nn+i);
			sup = j;
		}
		
		energy_contribution(energy_pairs, state, inf, sup, L, N, J);	
		E1 = E1 + *(energy_pairs+inf*(N-1)-inf*(inf-1)/2+sup-(inf+1));
	}
	
	
	//accepting or reversing the move as Metropolis
	double r = 0;
	if(E1>E0){
		r = uniform();
		//printf("%f\t%f\t%f\t%f\n", r, E0, E1, exp(-beta*(E1-E0))); //debugging
		
		if(r > exp(-beta*(E1-E0))){
			//invert the move (reject the move)
			*(state + j) = *(state+j)*(-1);
			for(int i = 0; i <4; i++){
				energy_contribution(energy_pairs, state, j, *(nn+i), L, N, J);
			}
		}else{//otherwise keep the move 
			//adjourn energy and magnetization
			*energy = *energy +(E1-E0);  //adjourn total energy
			*magnetization = *magnetization +2* *(state+j); //adjourn total magnetization
		}
		
	}else{//otherwise keep the move 
			//adjourn energy and magnetization
			*energy = *energy +(E1-E0);  //adjourn total energy
			*magnetization = *magnetization +2* *(state+j); //adjourn total magnetization
	}
	//otherwise keep the move 
}

//Update using Wolff Cluster algorithm
void update_wolff(int * state, int * cluster, int * cluster_size, int * nn, double * p_add, int L, int N, double *energy, double *magnetization, double J){
	
	int seed_wolff = random_integer(0, N-1); //sampling the seed
	double r = 0; //used to draw probabilities
	int count = 0;  //used to count the cluster elements
	int position = 0; //to keep track of the position on the cluster array
	*(cluster + position) = seed_wolff;  //adding the first element of the cluster
	
	int present=0; //variable to check if a spin is already in the cluster
	int kink = 0; //to count the change in energy
	
	//Computing the cluster
	do{
		nearest_neighbours(*(cluster+position) , nn, L);	
		for(int i=0; i<4; i++){
		
			if(*(state+*(cluster+position))* *(state+*(nn+i))>0){
				
				for(int k=0; k<=count; k++){
					if(*(nn+i)==*(cluster+k)){
						present = 1;
					}
				}
				
				if(present==0){ 
				
					r = uniform();
					
					if(r<*p_add){
						count = count +1;
						*(cluster + count) = *(nn+i);
					}					
				}
					
				present=0;	
			}	
		}
		
		position=position+1;
		//printf("%d\t%d\n", position, count);
	}while(position<=count);
	
	//Adjourning the state of the cluster
	for (int k=0; k<= count; k++){
		*(state + *(cluster+k)) = *(state + *(cluster+k))*(-1); //flip the spin	
	}
	
	
	//Computing the kink to adjourn the energy
	present = 0;
	for (int k=0; k<=count; k++){
		
		nearest_neighbours(*(cluster+k), nn, L);
	
		for (int i=0; i<4; i++){
			for (int k2=0; k2<=count; k2++){
				if(*(nn+i)==*(cluster+k2)){
					present = 1;
				}
			}
			if(present == 0){
				kink = kink + (*(state+*(cluster+k)))* (*(state+*(nn+i)));
			}
			present = 0;		
		}
			
	}	
	
	*cluster_size = count +1; //adjourning the cluster size
	
	//Adjourning energy and magnetization
	*energy=*energy-2*J*kink;
	*magnetization=*magnetization+2*(count+1)* *(state+seed_wolff);
	
}


//Function tha search for the nn of a spin j; Implements also periodic boundary conditions
void nearest_neighbours(int j, int * nn, int L){
	//position on the lattice
	int x_j = j/L;
	int y_j = j%L;
	
	//updating the vector of nearest neighbours
	*(nn+0) = j -L;
	*(nn+1) = j -1;
	*(nn+2) = j +1;
	*(nn+3) = j +L;
	
	//Implementic periodic boundary conditions
	if(x_j == 0){
		*(nn+0) = L*L-L+j;
	}
	if(x_j == L-1){
		*(nn+3) = j+L-L*L;	
	}
	if(y_j == 0){
		*(nn+1) = j+L-1;
	}
	if(y_j == L-1){
		*(nn+2) = j - L + 1;
	}
}
